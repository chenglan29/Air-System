const fs = require("fs");
module.exports = (data,socket) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./software/login/client_script/loginUI.js").toString()
    }));
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./software/login/client_script/icon.js").toString()
    }));
    // socket.send(fs.readFileSync("./software/login/desktop/result.png"), { binary: true });
}