const fs = require("fs");
module.exports = (dir,data,socket) => {
    fs.readdirSync(dir).forEach(item=>{
        if(item.substr(item.length-3,3) == ".js")
            require(`../${dir}${item}`)(data,socket);
    });
}