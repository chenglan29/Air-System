const notificationArea = document.getElementById('notificationArea');
const historyPanel = document.getElementById('historyPanel');
const historyList = document.getElementById('historyList');
let notificationHistory = [];

// 显示通知
function showNotification(title, content, options = {}) {
    const {
        duration = 4000,
        actions = [],
        icon = null,
        persistent = false
    } = options;
    
    const notificationId = 'notif-' + Date.now();
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.id = notificationId;
    
    // 构建操作按钮
    let actionButtons = '';
    if (actions.length > 0) {
        actionButtons = `<div class="notification-actions">
            ${actions.map((action, i) => 
                `<button class="notification-btn ${i === 0 ? 'primary' : ''}" 
                        onclick="handleAction('${notificationId}', ${i})">
                    ${action}
                </button>`
            ).join('')}
        </div>`;
    }
    
    notification.innerHTML = `
        <div class="notification-header">
            <div class="notification-title">${title}</div>
            <button class="notification-close" onclick="closeNotification('${notificationId}')">×</button>
        </div>
        <div class="notification-content">${content}</div>
        ${actionButtons}
        ${duration > 0 && !persistent ? '<div class="notification-progress"></div>' : ''}
    `;
    
    notificationArea.prepend(notification);
    
    // 添加到历史记录
    addToHistory(title, content);
    
    // 显示动画
    setTimeout(() => {
        notification.classList.add('show');
        
        // 进度条动画
        if (duration > 0 && !persistent) {
            const progress = notification.querySelector('.notification-progress');
            if (progress) {
                progress.style.transition = `transform ${duration}ms linear`;
                setTimeout(() => {
                    progress.style.transform = 'scaleX(0)';
                }, 10);
            }
            
            // 自动关闭
            setTimeout(() => {
                closeNotification(notificationId);
            }, duration);
        }
    }, 10);
    
    return notificationId;
}

// 关闭通知
function closeNotification(id) {
    const notification = document.getElementById(id);
    if (notification) {
        notification.classList.remove('show');
        notification.classList.add('hide');
        
        setTimeout(() => {
            notification.remove();
        }, 300);
    }
}

// 处理操作按钮点击
function handleAction(notificationId, actionIndex) {
    console.log(`Notification ${notificationId} action ${actionIndex} clicked`);
    closeNotification(notificationId);
}

// 添加到历史记录
function addToHistory(title, content) {
    const historyItem = {
        id: 'hist-' + Date.now(),
        title,
        content,
        timestamp: new Date()
    };
    
    notificationHistory.unshift(historyItem);
    updateHistoryList();
    
    // 限制历史记录数量
    if (notificationHistory.length > 50) {
        notificationHistory.pop();
    }
}

// 更新历史记录列表
function updateHistoryList() {
    historyList.innerHTML = notificationHistory.map(item => `
        <li class="history-item" onclick="recreateNotification('${item.id}')">
            <div class="history-item-title">${item.title}</div>
            <div class="history-item-content">${item.content}</div>
            <div style="font-size:11px;color:#999;margin-top:4px;">
                ${formatTime(item.timestamp)}
            </div>
        </li>
    `).join('');
}

// 重新创建通知
function recreateNotification(historyId) {
    const item = notificationHistory.find(i => i.id === historyId);
    if (item) {
        showNotification(item.title, item.content, {persistent: true});
    }
}

// 清空历史记录
function clearHistory() {
    notificationHistory = [];
    updateHistoryList();
}

// 切换历史面板显示
function toggleHistory() {
    historyPanel.style.display = historyPanel.style.display === 'block' ? 'none' : 'block';
}

// 格式化时间
function formatTime(date) {
    return date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}

// // 示例：自动显示几个通知
// setTimeout(() => {
//     showNotification('欢迎', '您已成功登录系统');
// }, 1000);