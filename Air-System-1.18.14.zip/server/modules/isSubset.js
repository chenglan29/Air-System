module.exports = (subset,arr,callback) => {
    var b = 1;
    subset.forEach(item=>{
        var flag = 1;
        arr.forEach(ele=>{
            Object.keys(item).forEach(_item=>{
                if(item[_item] != ele[_item])flag = 0;
            });
        });
        if(flag == 0){
            callback(item);
        }
    })
}