const fs = require("fs");
module.exports = (versionNum, versionName, logger) => {
    var list = fs.readFileSync("./software/Boot-0.1/cmd.txt").toString().split("#");
    list.forEach((item,i) => {
        var a = global.terminal.length;
        global.terminalLog.push(``);
    logger.debug(global.terminalLog.length)
        if (process.platform == 'win32') {
            const pty = require('node-pty');
            global.terminal.push(pty.spawn('C:\\Windows\\System32\\cmd.exe'));
        }
        else {
            const { spawn } = require('child_process');
            global.terminal.push(spawn("true"));
        }
        global.terminal[a].onData((m) => {
            global.terminalLog[a] += m.toString();
        });
        global.terminal[a].write(list[i] + '\r\n');
    })
}