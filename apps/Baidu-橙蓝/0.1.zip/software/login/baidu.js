const fs = require("fs");
module.exports = (data,socket) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":`insert({ icon: "", name: "百度", dblclick: () => { new Window({ "title": "百度", "src": "http://m.baidu.com" }); } })`
    }));
}