const fs = require("fs");
const http = require('http');
tempServerFlag = 0;
module.exports = (data, socket, logger) => {
    // logger.debug(6)
    // logger.info(6)
    if (data.opera == "open.path") {
        fs.readdir(data.path, (err, files) => {
            if (err) {
                socket.send(JSON.stringify({
                    "type": "ptp",
                    "obj": "FM",
                    "err": err
                }));
            }
            else {
                var body = [];
                files.forEach(item => {
                    var ele = {
                        "name": item,
                        "isBlockDevice": fs.statSync(data.path + item).isBlockDevice(),
                        "isCharacterDevice": fs.statSync(data.path + item).isCharacterDevice(),
                        "isDirectory": fs.statSync(data.path + item).isDirectory(),
                        "isFIFO": fs.statSync(data.path + item).isFIFO(),
                        "isFile": fs.statSync(data.path + item).isFile(),
                        "stat": fs.statSync(data.path + item)
                    }
                    body.push(ele)
                });
                socket.send(JSON.stringify({
                    "type": "ptp",
                    "obj": "FM",
                    "opera": "open.path",
                    "msg": body
                }));
            }
        })
    }
    else if (data.opera == "write.text") {
        fs.writeFileSync(data.path, data.inner);
    }
    else if (data.opera == "delete.file") {
        fs.unlinkSync(data.path, (err) => {
            socket.send(JSON.stringify({
                "type": "eval",
                "script": `alert("执行失败\n${err}")`
            }));
        });
    }
    else if (data.opera == "delete.folder") {
        fs.rmSync(data.path, { recursive: true, force: true });
    }
    else if (data.opera == "open.text") {
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "FM",
            "opera": "open.text",
            "msg": fs.readFileSync(data.path).toString(),
            "name": data.path
        }));
    }
    else if (data.opera == "close.bit" && tempServerFlag == 1) {
        tempServer.close();
        logger.debug("http已关闭");
        tempServerFlag = 0;
    }
    else if (data.opera == "open.bit") {
        // 创建服务器
        // fs.statSync(data.path).size;
        if (tempServerFlag == 1) {
            tempServer.close();
            tempServerFlag = 0;
            logger.debug("通道冲突");
            socket.send(JSON.stringify({
                "type": "eval",
                "script": `alert("通道冲突，我们将上一个连接关闭了")`,
            }));
        }
        // else {
        tempServer = http.createServer(function (request, response) {
            // 从文件系统中读取请求的文件内容
            // HTTP 状态码: 200 : OK
            // Content Type: text/html
            if (request.url == `/${data.token}`) {
                clearTimeout(tempServerPrevent);
                logger.debug(fs.statSync(data.path).size);
                response.writeHead(200, {
                    'Content-Disposition': `attachment; filename="${data.name}"`,
                    'Content-Type': 'application/octet-stream'
                });
                // 响应文件内容
                response.end(fs.readFileSync(data.path));
                // setTimeout(() => {
                //     tempServer.close();
                //     logger.debug("http已关闭");
                //     tempServerFlag = 0;
                // }, fs.statSync(data.path).size / 1024);
            }
            else {
                response.writeHead(403, { 'Content-Type': 'text/html' });
                // 响应文件内容
                response.end("Token is invalid");
            }
        }).listen(8001, () => {
            tempServerFlag = 1;
            logger.debug("http已开启");
            tempServerPrevent = setTimeout(() => {
                tempServer.close();
                logger.debug("请求超时关闭");
                tempServerFlag = 0;
                socket.send(JSON.stringify({
                    "type": "eval",
                    "script": `alert("请求超时，可能是由于文件预览的IP错误导致的")`,
                }));
            }, 1000);
        });
        // }
    }
    else if (data.opera == "upload") {
        // 创建服务器
        // fs.statSync(data.path).size;
        if (tempServerFlag == 1) {
            tempServer.close();
            tempServerFlag = 0;
            logger.debug("通道冲突");
            socket.send(JSON.stringify({
                "type": "eval",
                "script": `alert("通道冲突，我们将上一个连接关闭了")`,
            }));
        }
        const WebSocket = require('ws');
        const wss = new WebSocket.Server({ port: 8001 });
        tempServerFlag = 1;
        wss.on('connection', (ws) => {
            var confirmFlag = 0;
            ws.on('message', (message) => {
                if (data.token == message && confirmFlag == 0) {
                    confirmFlag = 1;
                    clearTimeout(tempServerPrevent)
                }
                else if (confirmFlag == 1) {
                    const buffer = Buffer.from(message);
                    var tempName = `${data.path}上传的文件-${new Date().getHours()}-${new Date().getMinutes()}-${new Date().getSeconds()}`
                    fs.writeFile(tempName, buffer, function (err) {
                        if (err) {
                            logger.debug('文件保存失败:', err);
                            return;
                        }
                        wss.close();
                        socket.send(JSON.stringify({
                            "type": "eval",
                            "script": `readdir();`,
                        }));
                        tempServerFlag = 0;
                        logger.debug('文件保存成功！');
                    });
                }
            });
        });
        tempServerPrevent = setTimeout(() => {
            tempServerFlag = 0;
            wss.close();
            socket.send(JSON.stringify({
                "type": "eval",
                "script": `alert("请求超时，可能是由于文件预览的IP错误导致的")`,
            }));
            logger.debug('请求超时关闭');
        }, 2000)
    }
}