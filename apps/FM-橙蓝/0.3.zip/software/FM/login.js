const fs = require("fs");
module.exports = (data,socket,logger) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./software/FM/client.js").toString().replace(/#inner#/gi,fs.readFileSync("./software/FM/client.html").toString())
    }));
    // socket.send(fs.readFileSync("./software/login/desktop/result.png"), { binary: true });
    //FileManager

}