FileManager = () => {
    new Window({
        "title": "File Manager",
        "content": `#inner#`
    });
    readdir();
}
document.head.innerHTML += `
<style>
    #folders a {
        color: #08C;
    }
</style>
`;
messageListen.folders = (event) => {
    if (typeof (event.data) == "object") {
    }
    else if (data.type == "ptp" && data.obj == "FM") {
        data = JSON.parse(event.data);
        console.log(data);
        if (data.opera == "open.path") {
            if (data.err) {
                if (data.err.code == "ENOENT") {
                    document.getElementById("folders").innerHTML = "<tr><td>没有这样的文件或目录</td><tr/>";
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
                else if (data.err.code == "ENOTDIR") {
                    document.getElementById("folders").innerHTML = "<tr><td>不是一个目录</td><tr/>";
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
                else if (data.err.code == "EBUSY") {
                    document.getElementById("folders").innerHTML = "<tr><td>资源被占用或锁定导致无法执行操作</td><tr/>";
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
                else if (data.err.code == "EPERM") {
                    document.getElementById("folders").innerHTML = "<tr><td>当前操作因权限不足或权限配置错误被系统拒绝</td><tr/>";
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
                else {
                    document.getElementById("folders").innerHTML = `<tr><td>${JSON.stringify(data.err)}</td><tr/>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
            }
            else if (data.msg.length == 0) {
                document.getElementById("folders").innerHTML = "<tr><td>空目录</td><tr/>";
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
            }
            else {
                document.getElementById("folders").innerHTML = `<tr>
                    <td>名称</td>
                    <td style="min-width: 250px;">打开方式</td>
                    <td>文件大小</td>
                    <td>创建时间</td>
                    <td>访问时间</td>
                    <td>blksize</td>
                    <td>blocks</td>
                    <td>ctime</td>
                    <td>dev</td>
                    <td>gid</td>
                    <td>ino</td>
                    <td>mode</td>
                    <td>mtime</td>
                    <td>nlink</td>
                    <td>rdev</td>
                    <td>uid</td>
                    <td>isBlockDevice</td>
                    <td>isCharacterDevice</td>
                    <td>isDirectory</td>
                    <td>isFIFO</td>
                    <td>isFile</td>
                </tr>
                <tr>
                    <td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td>
                </tr>
                <tr>
                    <td><input type="file" id="fileInput"></td>
                    <td><button onclick="uploadFile()">上传</button></td>
                </tr>
                `;
                var i = 0;
                data.msg.forEach(item=>{
                    console.log(item);
                        document.getElementById("folders").innerHTML += `<tr>
                            <td>
                                ${(item.isDirectory == true) ? `<a ondblclick="document.getElementById('FileManagerPath').value +=\`${item.name}/\`;readdir()">` : ""}
                                ${
                                    item.name + 
                                    ((item.isDirectory == true) ? "/</a>" : "")
                                }
                            </td>
                            <td>
                                <a ondblclick="openText(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);">文本编辑器</a> /
                                <a ondblclick="openImg(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);">图片浏览</a> /
                                <a ondblclick="openURL(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);">下载</a> /
                                ${(item.isFile == true) ? "<a ondblclick=\"deleteFile(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);\">删除</a>" : ""}
                                ${(item.isDirectory == true) ? "<a ondblclick=\"deleteFolder(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);\">删除</a>" : ""}
                            </td>
                            <td>${(item.isDirectory == true) ? "未计算" : ((item.stat.size > 1024) ? ((item.stat.size > 1024 * 1024) ? ((item.stat.size > 1024 * 1024 * 1024) ? (item.stat.size / 1024 / 1024 / 1024).toFixed(1) + "GB" : (item.stat.size / 1024 / 1024).toFixed(1) + "MB") : (item.stat.size / 1024).toFixed(1) + "KB") : item.stat.size + "B")}</td>
                            <td>${item.stat.birthtime}</td>
                            <td>${item.stat.atime}</td>
                            <td>${item.stat.blksize}</td>
                            <td>${item.stat.blocks}</td>
                            <td>${item.stat.ctime}</td>
                            <td>${item.stat.dev}</td>
                            <td>${item.stat.gid}</td>
                            <td>${item.stat.ino}</td>
                            <td>${item.stat.mode}</td>
                            <td>${item.stat.mtime}</td>
                            <td>${item.stat.nlink}</td>
                            <td>${item.stat.rdev}</td>
                            <td>${item.stat.uid}</td>
                            <td>${item.isBlockDevice}</td>
                            <td>${item.isCharacterDevice}</td>
                            <td>${item.isDirectory}</td>
                            <td>${item.isFIFO}</td>
                            <td>${item.isFile}</td>
                        </tr>`;
                })
            }
        }
        else if (data.opera == "open.text") {
            new Window({
                "title": data.name,
                "content": `
                    <div style="widtht: 100%;height: 4%;display: flex;">
                        <input type="text" value="${data.name}" />
                        <button onclick="saveFile(this)">保存</button>
                    </div>
                    <textarea style="width: 100%;height:94%;border: none;resize: none;">${data.msg}</textarea>
                `
            });
        }
    }
};
saveFile = (t) => {
    var path = document.querySelector("body > div:nth-child(16) > div.content > div > button").parentNode.children[0].value;
    var inner = document.querySelector("body > div:nth-child(16) > div.content > div > button").parentNode.parentNode.children[1].value;
    var titleEle = t.parentNode.parentNode.parentNode.childNodes[0].childNodes[0];
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "write.text",
        "path": path,
        "inner": inner
    }));
    titleEle.innerHTML = path + " - 保存成功";
    setTimeout(() => {
        titleEle.innerHTML = path;
    }, 1000);
}
readdir = () => {
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "open.path",
        "path": document.getElementById("FileManagerPath").value
    }));
}
openText = (name) => {
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "open.text",
        "token": (Math.random() * Math.pow(10, 17)).toString(36),
        "path": name
    }));
}
viewIP = "";
openImg = (name) => {
    viewIP = prompt("请提供viewIP(一般为8001端口) 进行文件传输\n例如 127.0.0.1:8001", viewIP);
    var token = (Math.random() * Math.pow(10, 17)).toString(36);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "open.bit",
        "token": token,
        "name": name,
        "path": name
    }));
    new Window({
        "title": name,
        "content": `<img src="http://${viewIP}/${token}" onload="closeHttp();" />`
    });
}
openURL = (name) => {
    viewIP = prompt("请提供viewIP(一般为8001端口) 进行文件传输\n例如 127.0.0.1:8001", viewIP);
    var token = (Math.random() * Math.pow(10, 17)).toString(36);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "open.bit",
        "token": token,
        "name": name,
        "path": name
    }));
    window.open(`http://${viewIP}/${token}`);
}
deleteFile = (name) => {
    viewIP = prompt("您正在删除文件，请注意！！！！！！！！！！！！！！\n请提供viewIP(一般为8001端口) 进行文件传输\n例如 127.0.0.1:8001", viewIP);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "delete.file",
        "path": name
    }));
    readdir();
}
deleteFolder = (name) => {
    viewIP = prompt("您正在删除文件，请注意！！！！！！！！！！！！！！\n请提供viewIP(一般为8001端口) 进行文件传输\n例如 127.0.0.1:8001", viewIP);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "delete.folder",
        "path": name
    }));
    readdir();
}
closeHttp = () => {
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "close.bit"
    }));
}
uploadFile = () => {
    viewIP = prompt("请提供viewIP(一般为8001端口) 进行文件传输\n例如 ws://127.0.0.1:8001", viewIP);
    var token = (Math.random() * Math.pow(10, 17)).toString(36);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "upload",
        "token": token,
        "path":document.getElementById("FileManagerPath").value
    }));
    var tempServer = new WebSocket(viewIP);
    tempServer.onopen = function () {
        tempServer.send(token);
        
        var fileInput = document.getElementById('fileInput');
        var reader = new FileReader();
        var file = fileInput.files[0];

        reader.onload = function () {
            var arrayBuffer = this.result;
            tempServer.send(arrayBuffer);
        };

        reader.readAsArrayBuffer(file);
    };
}
insert({ icon: "", name: "File Manager", dblclick: () => { FileManager(); } })