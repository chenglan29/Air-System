module.exports = (versionNum,versionName,logger) => {
    if(versionNum != 5)logger.warn(`软件 BrainFuck Compiler 的版本(0.1)与当前服务器版本(${versionName})不匹配，也许无法运行`);
}