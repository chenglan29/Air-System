const fs = require("fs");
module.exports = (data,socket) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":`insert({icon:"",name:"File Manager",dblclick:()=>{FileManager();}})`
    }));
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./debug/login/FileManager/main.js").toString().replace(/inner/gi,fs.readFileSync("./debug/login/FileManager/main.html").toString())
    }));
    // socket.send(fs.readFileSync("./software/login/desktop/result.png"), { binary: true });
}