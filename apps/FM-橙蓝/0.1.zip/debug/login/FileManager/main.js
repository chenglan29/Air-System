FileManager = () => {
    new Window({
        "title": "File Manager",
        "content": `#inner#`
    });
    readdir();
}
socket.onmessage = (event) => {
    if (typeof (event.data) == "object") {
    }
    else {
        data = JSON.parse(event.data);
        console.log(data);
        if (data.err) {
            if (data.err.code == "ENOENT") {
                document.getElementById("folders").innerHTML = "<tr><td>没有这样的文件或目录</td><tr/>";
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
            }
            else if (data.err.code == "ENOTDIR") {
                document.getElementById("folders").innerHTML = "<tr><td>不是一个目录</td><tr/>";
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
            }
            else if (data.err.code == "EBUSY") {
                document.getElementById("folders").innerHTML = "<tr><td>资源被占用或锁定导致无法执行操作</td><tr/>";
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
            }
            else if (data.err.code == "EPERM") {
                document.getElementById("folders").innerHTML = "<tr><td>当前操作因权限不足或权限配置错误被系统拒绝</td><tr/>";
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
            }
            else {
                document.getElementById("folders").innerHTML = `<tr><td>${JSON.stringify(data.err)}</td><tr/>`;
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
            }
        }
        else if (data.msg.length == 0){
            document.getElementById("folders").innerHTML = "<tr><td>空目录</td><tr/>";
            document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
            document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
        }
        else {
            document.getElementById("folders").innerHTML = `<tr>
                <td>名称</td>
                <td>文件大小</td>
                <td>创建时间</td>
                <td>访问时间</td>
                <td>blksize</td>
                <td>blocks</td>
                <td>ctime</td>
                <td>dev</td>
                <td>gid</td>
                <td>ino</td>
                <td>mode</td>
                <td>mtime</td>
                <td>nlink</td>
                <td>rdev</td>
                <td>uid</td>
                <td>isBlockDevice</td>
                <td>isCharacterDevice</td>
                <td>isDirectory</td>
                <td>isFIFO</td>
                <td>isFile</td>
            </tr>
            <tr>
                <td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td>
            </tr>
            `;
            data.msg.forEach(item => {
                document.getElementById("folders").innerHTML += `<tr>
                    <td>${(item.isDirectory==true)?`<a ondblclick="document.getElementById('FileManagerPath').value +=\`${item.name}/\`;readdir()">`:""}${item.name}${(item.isDirectory==true)?"/</a>":""}</td>
                    <td>${(item.isDirectory==true)?"未计算":((item.stat.size>1024)?((item.stat.size>1024*1024)?((item.stat.size>1024*1024*1024)?(item.stat.size/1024/1024/1024).toFixed(1)+"GB":(item.stat.size/1024/1024).toFixed(1)+"MB"):(item.stat.size/1024).toFixed(1)+"KB"):item.stat.size+"B")}</td>
                    <td>${item.stat.birthtime}</td>
                    <td>${item.stat.atime}</td>
                    <td>${item.stat.blksize}</td>
                    <td>${item.stat.blocks}</td>
                    <td>${item.stat.ctime}</td>
                    <td>${item.stat.dev}</td>
                    <td>${item.stat.gid}</td>
                    <td>${item.stat.ino}</td>
                    <td>${item.stat.mode}</td>
                    <td>${item.stat.mtime}</td>
                    <td>${item.stat.nlink}</td>
                    <td>${item.stat.rdev}</td>
                    <td>${item.stat.uid}</td>
                    <td>${item.isBlockDevice}</td>
                    <td>${item.isCharacterDevice}</td>
                    <td>${item.isDirectory}</td>
                    <td>${item.isFIFO}</td>
                    <td>${item.isFile}</td>
                </tr>`;
            })
        }
    }
};
readdir = () => {
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FileManager.js",
        "path": document.getElementById("FileManagerPath").value
    }));
}
