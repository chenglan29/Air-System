const fs = require("fs");
module.exports = (data, socket,logger) => {
    logger.info(6)
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FileManager",
        "msg": fs.readdirSync(data.path)
    }));
}