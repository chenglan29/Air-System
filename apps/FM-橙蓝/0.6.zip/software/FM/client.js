FileManager = () => {
    new Window({
        "title": "File Manager",
        "content": `#inner#`
    });
    readdir();
}
document.head.innerHTML += `
<style>
    #folders a {
        color: #08C;
    }
</style>
`;
messageListen.folders = (event) => {
    if (typeof (event.data) == "object") {
    }
    else if (data.type == "ptp" && data.obj == "FM") {
        data = JSON.parse(event.data);
        console.log(data);
        if (data.opera == "open.path") {
            if (data.err) {
                if (data.err.code == "ENOENT") {
                    document.getElementById("folders").innerHTML = "<tr><td>没有这样的文件或目录</td><tr/>";
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
                else if (data.err.code == "ENOTDIR") {
                    document.getElementById("folders").innerHTML = "<tr><td>不是一个目录</td><tr/>";
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
                else if (data.err.code == "EBUSY") {
                    document.getElementById("folders").innerHTML = "<tr><td>资源被占用或锁定导致无法执行操作</td><tr/>";
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
                else if (data.err.code == "EPERM") {
                    document.getElementById("folders").innerHTML = "<tr><td>当前操作因权限不足或权限配置错误被系统拒绝</td><tr/>";
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
                else {
                    document.getElementById("folders").innerHTML = `<tr><td>${JSON.stringify(data.err)}</td><tr/>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                    document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
                }
            }
            else if (data.msg.length == 0) {
                document.getElementById("folders").innerHTML = "<tr><td>空目录</td><tr/>";
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td></tr>`;
                document.getElementById("folders").innerHTML += `<tr><td><a ondblclick="document.getElementById('FileManagerPath').value ='./';readdir()">./</a></td></tr>`;
            }
            else {
                document.getElementById("folders").innerHTML = `<tr>
                    <td>名称</td>
                    <td style="min-width: 275px;">打开方式</td>
                    <td>文件大小</td>
                    <td style="min-width: 250px;">创建时间</td>
                    <td style="min-width: 250px;">访问时间</td>
                    <td>blksize</td>
                    <td>blocks</td>
                    <td style="min-width: 250px;">ctime</td>
                    <td>dev</td>
                    <td>gid</td>
                    <td>ino</td>
                    <td>mode</td>
                    <td style="min-width: 250px;">mtime</td>
                    <td>nlink</td>
                    <td>rdev</td>
                    <td>uid</td>
                    <td>isBlockDevice</td>
                    <td>isCharacterDevice</td>
                    <td>isDirectory</td>
                    <td>isFIFO</td>
                    <td>isFile</td>
                </tr>
                <tr>
                    <td><a ondblclick="document.getElementById('FileManagerPath').value +='../';readdir()">../</a></td>
                </tr>
                <tr>
                    <td><input type="file" id="fileInput"></td>
                    <td><button onclick="uploadFile()">上传</button></td>
                </tr>
                `;
                var i = 0;
                data.msg.forEach(item => {
                    console.log(item);
                    document.getElementById("folders").innerHTML += `<tr>
                            <td>
                                ${(item.isDirectory == true) ? `<a ondblclick="document.getElementById('FileManagerPath').value +=\`${item.name}/\`;readdir()">` : ""}
                                ${item.name +
                        ((item.isDirectory == true) ? "/</a>" : "")
                        }
                            </td>
                            <td>
                                ${(item.isFile == true) ? "<a ondblclick=\"openText(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);\">文本编辑器</a> /" : ""}
                                ${(item.isFile == true) ? "<a ondblclick=\"openImg(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);\">图片浏览</a> /" : ""}
                                ${(item.isFile == true) ? "<a ondblclick=\"openURL(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);\">下载</a> /" : ""}
                                ${(item.isFile == true) ? "<a ondblclick=\"deleteFile(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);\">删除</a>" : ""}
                                ${(item.isDirectory == true) ? "<a ondblclick=\"deleteFolder(document.getElementById('FileManagerPath').value+this.parentNode.parentNode.children[0].innerText);\">删除</a>" : ""}
                            </td>
                            <td>${(item.isDirectory == true) ? "未计算" : ((item.stat.size > 1024) ? ((item.stat.size > 1024 * 1024) ? ((item.stat.size > 1024 * 1024 * 1024) ? (item.stat.size / 1024 / 1024 / 1024).toFixed(1) + "GB" : (item.stat.size / 1024 / 1024).toFixed(1) + "MB") : (item.stat.size / 1024).toFixed(1) + "KB") : item.stat.size + "B")}</td>
                            <td>${new Date(item.stat.birthtimeMs)}</td>
                            <td>${new Date(item.stat.atimeMs)}</td>
                            <td>${item.stat.blksize}</td>
                            <td>${item.stat.blocks}</td>
                            <td>${new Date(item.stat.ctimeMs)}</td>
                            <td>${item.stat.dev}</td>
                            <td>${item.stat.gid}</td>
                            <td>${item.stat.ino}</td>
                            <td>${item.stat.mode}</td>
                            <td>${new Date(item.stat.mtimeMs)}</td>
                            <td>${item.stat.nlink}</td>
                            <td>${item.stat.rdev}</td>
                            <td>${item.stat.uid}</td>
                            <td>${item.isBlockDevice}</td>
                            <td>${item.isCharacterDevice}</td>
                            <td>${item.isDirectory}</td>
                            <td>${item.isFIFO}</td>
                            <td>${item.isFile}</td>
                        </tr>`;
                })
            }
        }
        else if (data.opera == "open.text") {
            new Window({
                "title": data.name,
                "content": `
                    <div style="widtht: 100%;height: 4%;display: flex;">
                        <input type="text" value="${data.name}" />
                        <button onclick="saveFile(this)">保存</button>
                    </div>
                    <textarea style="width: 100%;height:94%;border: none;resize: none;">${data.msg}</textarea>
                `
            });
        }
    }
};
saveFile = (t) => {
    var path = document.querySelector("body > div:nth-child(16) > div.content > div > button").parentNode.children[0].value;
    var inner = document.querySelector("body > div:nth-child(16) > div.content > div > button").parentNode.parentNode.children[1].value;
    var titleEle = t.parentNode.parentNode.parentNode.childNodes[0].childNodes[0];
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "write.text",
        "path": path,
        "inner": inner
    }));
    titleEle.innerHTML = path + " - 保存成功";
    setTimeout(() => {
        titleEle.innerHTML = path;
    }, 1000);
}
readdir = () => {
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "open.path",
        "path": document.getElementById("FileManagerPath").value
    }));
}
openText = (name) => {
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "open.text",
        "token": (Math.random() * Math.pow(10, 17)).toString(36),
        "path": name
    }));
}
viewIP = "";
openImg = (name) => {
    viewIP = prompt("请提供viewIP(一般为8001端口) 进行文件传输\n例如 127.0.0.1:8001", viewIP);
    var token = (Math.random() * Math.pow(10, 17)).toString(36);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "open.bit",
        "token": token,
        "name": name,
        "path": name
    }));
    new Window({
        "title": name,
        "content": `<img src="http://${viewIP}/${token}" onload="closeHttp();" />`
    });
}
openURL = (name) => {
    viewIP = prompt("请提供viewIP(一般为8001端口) 进行文件传输\n例如 127.0.0.1:8001", viewIP);
    var token = (Math.random() * Math.pow(10, 17)).toString(36);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "open.bit",
        "token": token,
        "name": name,
        "path": name
    }));
    window.open(`http://${viewIP}/${token}`);
}
deleteFile = (name) => {
    viewIP = prompt("您正在删除文件，请注意！！！！！！！！！！！！！！\n请提供viewIP(一般为8001端口) 进行文件传输\n例如 127.0.0.1:8001", viewIP);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "delete.file",
        "path": name
    }));
    readdir();
}
deleteFolder = (name) => {
    viewIP = prompt("您正在删除文件，请注意！！！！！！！！！！！！！！\n请提供viewIP(一般为8001端口) 进行文件传输\n例如 127.0.0.1:8001", viewIP);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "delete.folder",
        "path": name
    }));
    readdir();
}
closeHttp = () => {
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "close.bit"
    }));
}
uploadFile = () => {

    var fileInput = document.getElementById('fileInput');
    var reader = new FileReader();
    var file = fileInput.files[0];

    var token = (Math.random() * Math.pow(10, 17)).toString(36);
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "FM",
        "opera": "upload",
        "token": token,
        "name": file.name,
        "path": document.getElementById("FileManagerPath").value
    }));
    viewIP = prompt("请提供viewIP(一般为8001端口) 进行文件传输\n例如 ws://127.0.0.1:8001", viewIP);
    var tempServer = new WebSocket(viewIP);
    tempServer.onopen = function () {

        tempServer.send(token);

        reader.onload = function () {
            var arrayBuffer = this.result;
            tempServer.send(arrayBuffer);
        };

        reader.readAsArrayBuffer(file);
    };
}
var icon = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAOPklEQVR4Xu2de4xdVRWH1zrDtMVaa6CA5aEGC2LRsXfvMzOaifIwIo+A/yBPQR4xMa3yCkowEioomhCFAiXgg4eIBNBINIAgwWJscGbOPjNBacJD5A8sRigRJJnEzr3LbHKJ1XTavc897/07SdM0s/Zea33rfj1z7z33XCYcIAACCxJgsAEBEFiYAATBowMEdkEAguDhAQIQBI8BEMhGAGeQbNywKhACECSQQaPNbAQgSDZuWBUIAQgSyKDRZjYCECQbN6wKhAAECWTQaDMbAQiSjRtWBUIAggQyaLSZjQAEycYNqwIhAEECGTTazEYAgmTjhlWBEKi1IFrrFcy8NxGtIKLhQGYSSpvbiehVEdlmjHm1rk3XShCl1CpmPk5EjrN/1xUa6iqEwP0i8lCv19s0Ozv7YiEZMmxaC0H6YlxARF/J0AOWtI/AjSJyQ5qmz1fdWuWCKKXWM7MVY6+qYSB/rQi8JiI3pmm6vsqqKhVEa72BiOyZAwcILETgEWPMsVXhqUwQrfXfiWi/qhpH3kYReMMYs7yKiisRRGv9EhEdUEXDyNlYAk8bYz5cdvWlC6K1/h0RHVl2o8jXCgL3G2NOKbOTUgXpPyG/sswGkatdBETkm2U+cS9NEK31SiJKiGj/do0M3ZRMYCsRxcaYl8vIW5ogOHuUMc4wcpR5FilNEK31M0R0aBgjRJcFE3jBGPOBgnO8tX0pgsRxfKSI2CfnOEAgFwLMfEKSJA/lstkuNilFkAHeELRnndtF5Okoit4sGgb2L53AmIicSUQjvplF5NY0Tb/ku843vixBJolozKc4EXmMmU+v85WePv0gdmECSqkrmdn3kpIpY8x40VzLEuQvRHSwRzOvdLvdidnZ2ec81iC0wQSUUlPMPOrRQinPQ8oS5J9E5HOpwM3GmHUesBDacAJa6zuJ6GyPNl43xrzbIz5TaFmCiE91Zb6M51MXYosjkOVtAGNM4Y/fwhNYpFprCFLcY6sVO0MQjzHiDOIBqyWhEMRjkBDEA1ZLQiGIxyAhiAesloRCEI9BQhAPWC0JhSAeg4QgHrBaEgpBPAYJQTxgtSQUgngM0goSRdEmjyWtDk2SpPUsghRkZGRk30WLFl0qIl9t9SO44OaY+ZIkSa4rOE2l2wcliFLqaCL6IjOfVin1diXfYIy5qF0t/bebIARRStnLlq9m5pPaOsiK+/olEa0r6+OmZfbaekGUUh9j5ruIaFWZYAPMlRLRWmOM/QhBa45WC2J/pWLmu4noPa2ZWL0b2SYia9M0va/eZbpX11pBlFInMvPPiOid7jgQmQcBEflamqbX5rFX1Xu0UpDR0dHRXq83VTXckPOLyE1pmjb+rvitFERrfTsRnRPyA7QOvTPzr4eGhtZOTk7aW7o28midILhTSe0eh08x89okSTbXrjKHgloniNbaPkH8nEPvCCmPgP1os30Z2D4nbNTRKkHiOD5eRB5s1ATCKvZyY8x3m9RyqwTRWm+0r8U3aQAB1nqLMcbOyOvjzlVxapsgmb7CQERuI6LJKIqerWoQdc4rIvZX1tz+4xGRh3u93to6fSnmQvzbJsgbRLTM58HGzGckSXKPz5oQY7XWioiuJ6JP5NS/vSvluunp6Sdy2q+QbVojSKfTWR1F0dM+lPD5Dh9aRBMTE8vm5uY2MvNZfisXjH6z/wqXvRSolkdrBInj+HQR8X2VZP82XmBX9CNNa30VEV2RY54rjDHfynG/3LZqjSB1bSS3SdVsoziOzxMR+6LIkpxK+1H/YsftOe2XyzZ1fVx53ziuro3kMqWabtK/GNRKclhOJT4qIuvSNH0+p/0G3qaujysIMvBoy9lgdHT0YHsmEZG8vjP8mf4VwY+X08Gus0CQOkyh+TVE/feg8vpejLn+mcReU1fpAUEqxd+u5Frry4got3fK7auMOROyb07u+NvJ//97p+mY2esbkGt58+q6mp7zgGu/nVLqVGa+iYhW1L7Y4gqcFJEbFy9e/PCTTz75WhFp8BykCKol7am1HreSiEhcUsq6ptkqIj9k5lvzfjsBgtR15I51jY+P7zc/P2/PJCc7LmlzmP0O9auNMbfk1SQEyYtkxftore1Hby+tuIxapM/zyg0IUouR5lOEUmpd/3lJPhs2e5cLjTE3DNoCBBmUYM3Wa61PICL7puL7alZa6eXkcVMLCFL62IpPODo6eni327UXOx5RfLZ6ZxCRc9M0vSNrlRAkK7marxsZGVk6PDxszyRfqHmpRZf3YrfbPSrrZ2IgSNHjqXj/OI7Xi4jXG3AVl1xE+sxfKw5BihhHzfZUSp3DzPZs8o6alVZWOa/0er3DZ2ZmXvFNCEF8iTU0vn+bJivJ6oa2MGjZ9m4vN/tuAkF8iTU4fs2aNe8fGhqykhzf4DYylW4/n5+mqXffECQTbiyqgkCn09kniiJ7Y4triGi5bw1zc3PLtmzZ8qbPOgjiQwuxtSCglNLMbL8r5SCfgpj5mCRJfuu1xifYxuJqXl9iiC+CQBzHX7ZX8nrufabvXSdxBvEkjPB6EBgbGzu02+0+41ONiFycpqm9pZLzAUGcUSGwbgS01l53jcxyESMEqdvUUY8zAQjijAqBIRKAICFOHT07E4AgzqgQGCIBCBLi1NGzMwEI4owKgSESgCAhTh09OxOAIM6oEBgiAQgS4tTRszMBCOKMCoEhEoAgIU4dPTsTgCDOqBAYIgEIEuLU0bMzAQjijAqBIRKAICFOHT07E4AgzqgQGCIBCBLi1NGzMwEI4owKgSESgCAhTh09OxOAIM6oEBgiAQgS4tTRszMBCOKMCoEhEoAgIU4dPTsTgCDOqBAYIgEIEuLU0bMzAQjijAqBIRKAICFOHT07E4AgzqgQGCIBCBLi1NGzMwEI4owKgSESgCAhTh09OxOAIM6oEBgiAQgS4tTRszMBCOKMCoEhEoAgIU4dPTsTgCDOqBAYIgEIEuLU0bMzAQjijAqBIRKAICFOHT07E4AgzqgQGCIBCBLi1NGzMwEI4owKgSESgCAhTh09OxOAIM6oEBgiAQgS4tTRszMBCOKMCoEhEoAgIU4dPTsTgCDOqBAYIgEIEuLU0bMzAQjijAqBIRKAICFOHT07E4AgzqgQGCIBCBLi1NGzMwEI4owKgSESgCAhTh09OxOAIM6oEBgiAQgS4tTRszMBCOKMCoEhEoAgIU4dPTsTgCDOqBAYIgEIEuLU0bMzAQjijAqBIRKAICFOHT07E4AgzqgQGCIBCBLi1NGzMwEI4owKgSESgCAhTh09OxOAIM6oEBgiAQgS4tTRszMBCOKMCoEhEoAgIU4dPTsTgCDOqBAYIgEIEuLU0bMzAQjijAqBIRKAICFOHT07E4AgzqgQGCIBCBLi1NGzMwEI4owKgSESqKUgWuvLiegan4EsWbLkXZs3b/6XzxrEgsDuCPgKQkRfN8Z8Z3f77vhz9gm2sUqpc5j5dp91zHxUkiSbfNYgFgR2RWDNmjWHDA0NPetDSUTOTdP0Dp813oJorY8hokd8khDRpcaY73muQTgILEhAKXURM1/niegzxphHfdZkEeQjRPSUTxIiuscYc4bnGoSDwIIE4jj+lYic6IloxBjzJ5813oKMjY3t3e12X/VJQkTPGmM+6LkG4SCwUwKrVq1avHz58q1EtJcPoqGhoRVTU1PbfNZ4C2I311r/g4j28UrEfH6SJLf5rEEsCOyMQBzHnxWRBzzpbDPGrPBcQ1kF2UhEaz2T/c0Yc6DnGoSDwP8QWL169aI999zz90Q07onmDmPMuZ5rsgmilDqWmR/2TUZE9xljTs2wDktA4C0CSqn1zHylLw5mPjlJkl94r/NdYOP7Fr/k+2uWXSsih6Rp+nyWvFgTNgGttT1r/DEDhdfm5uZWbtmy5d++azP9itV/HnInEZ3tm9DGR1HUmZ6ens2yFmvCJKCUWsXMz2Xs/m5jzOezrM0sSBzHx4vIg1mS9s8kF6dpen3W9VgXDgGt9b1EdErWjpn5hCRJHsqyPrMg/bPIQIUT0QNRFF27dOnSqU2bNs1naQBr2ksgjuPzROQqIjpggC4Het47kCCdTueTURQ9MUDxby99nYhmiChh5j8Qkf03jsAIiMhhRGT/fKj/93sHRdDr9Y6YmZmxr3plOgYSxGZUSv2Ymc/LlB2LQKBAAiJyW5qm5w+SYmBBOp3OR6Moste37DtIIVgLAjkT+Cszn5QkyZ8H2XdgQfpnEe8rfAcpGmtBYHcEoij69PT09GO7i9vdz3MRxCbRWturdS/ZXUL8HASKJiAiZ6Vp+tM88uQmiC0m4xWWefSBPUDgLQIicleappnen9sZwlwF6f+69X1mvhjzAoGyCTDzvUmSnJZn3twF6Utyii02z0KxFwjsioCIfDtN02/kTakQQWyR/fdIfkBE+BxI3lPDfjsSeIGZL0uS5OdFYClMEFvs+Pj4gfPz8xcS0QVEtKiIBrBnsATshYc37LHHHhsmJyfthbOFHIUK8nbFWmtFRFaU3J48FUIDmzaFwE+IaIMxJi264FIEebuJ/udI7JOoo4nooKKbw/6tIvCCiNg749yfpulvyuqsVEF2bKrT6Xw8iqJPEZH9sz8RrSSiZWU1jjy1JmDvofYyEdnPndsrxh8v42yxMyKVCbKzYiYmJpZt3759Za/Xs8LgCIxAFEVbh4eHX67TTQZrJUhgjwe02wACEKQBQ0KJ1RGAINWxR+YGEIAgDRgSSqyOAASpjj0yN4AABGnAkFBidQQgSHXskbkBBCBIA4aEEqsjAEGqY4/MDSAAQRowJJRYHQEIUh17ZG4AAQjSgCGhxOoIQJDq2CNzAwhAkAYMCSVWRwCCVMcemRtAAII0YEgosToC/wGaHcMyfrqLuQAAAABJRU5ErkJggg==`;
insert({ icon: icon, name: "File Manager", dblclick: () => { FileManager(); } })