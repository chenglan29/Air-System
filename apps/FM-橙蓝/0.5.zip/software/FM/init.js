module.exports = () => {
    global.tempServerFlag = 0;
}