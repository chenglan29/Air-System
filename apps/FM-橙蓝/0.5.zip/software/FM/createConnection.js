const fs = require("fs");
module.exports = (socket,logger) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./software/FM/init.js").toString().replace(/#inner#/gi,fs.readFileSync("./software/FM/init.html").toString())
    }));
    // socket.send(fs.readFileSync("./software/login/desktop/result.png"), { binary: true });
    //FileManager

}