const fs = require("fs");
module.exports = (socket,logger) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./software/Vue-2.6.14/vue.min.js").toString()
    }));
    // socket.send(fs.readFileSync("./software/login/desktop/result.png"), { binary: true });
    //FileManager

}