
module.exports = () => {
    global.terminal = [];
    global.terminalLog = [];
    require("./create")();
}