var icon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAN4AAADICAYAAACH6F8xAAAO5klEQVR4Xu2deaxdVRWHPzROSEWLGsNoSYsBo6CCA2CYpDWFoqQyWSMgqBUrgrQISoRGCShTYlsQEBkFRIIClRZEIBhAAgiIzCBjBAJ/aCCRSTHrsZ+5fd777tlnr3vO2ef8dvLykr691tr7W/vXM+1hNV4v+wLzgXXCT/hn/RIBEUgkcBNwO3AZcOW4r9WAPYELEp3LXAREYDiBM4D9rZoJ73xgr+E2qiECIuBAYBFwvAnvL8CHHBzKhQiIQDECa5vwngPWKlZftURABBwIzDHhvebgSC5EQASKE1gs4RWHpZoi4EVAwvMiKT8iEEFAwouApaoi4EVAwvMiKT8iEEFAwouApaoi4EVAwvMiKT8iEEFAwouApaoi4EVAwvMiKT8iEEFAwouApaoi4EVg5MJ7OMwFvQ24AfhYz89GXr3o8fNCiGfzT28EXp0Qc4pzzGeAO4E7Qv/eNyGeczi5awmBkQrvQGDJJKBs/d9xwBpOME8HjgYeG+BvBrAUmOkU74gQb5C72SHeNKd4ctMeAiMR3tPAV4AVBTi9Bbga2LpA3UFVngUWABcV9HEMcFjBuv2q2ZX0IOCWgj5WArMK1lW1bhBwF96LwJZhxW0MwkuAXWMMeuralaWIyHvdzwPOKxHPrqafAOwWM6ak9C8mjurmQcBdeHarZ7dgsWVN4B+xRmHl/BdL2JmJCc8EGFPGFjHGGIS6ZftXIpRMMiDgKrx7w9WujICMld0uTvZM2I/nVuElShnW9sz3J2BqQWN7YWNXO7uqlyll+lcmjmyaT8BVeAuBExL7bLdw7y3ow27f5hasO6hazFXvEODExHgx/UsMJfMGE3AV3g7ANYmd/QOwfUEfw94qFnFjL1nsZUuRsg1wfZGKk9SJ6V9iKJk3mICr8N5V8jmtl89PgW8VBLYTcEXBuoOqfQb4fUEfqwP/Klh3ULWY/iWGknmDCbgJ7z5gY4eOxrxtXBt4KjHmO4B/FvBhEwA2L1BvWJWY/g3zpb/nS6DzwrP/LO4pkL8ngfUK1BtWRcIbRqgbf3cTnuHK8VZzH+DMgrleH3iiYF3daiaCarm5q/ByfLlibykPLpjkz4VtuAtW71tNL1dS6LXH1lV4OX5OuArYsWA+FwNHFaw7qJo+JyQCbIm5q/AeBVImBNt3sthZIV8Gzi2ZjL2BsyJsbeWDTYe7K8Kmt2qZ/pUMJbOGE3AVnvXVBrKdPBRbTLB/izUKcyZtKU5ssRURz8caAWcD9lwYW8r2LzaO6udBwF141m3bJDe2PAhMjzUK9c8B7OoVU2yqmE3/KlNsbmjs6Uop/SvTRtk0m8BIhGddtqlcNqVrWNk2LOd5z7CKQ/5uQtivwAfuTYHlwLqJ8Y4FDi/gw6t/BUKpSkYERiY8Y2DHfy0L69ZemQBlg3Aunw1gr/IAcGhYCW4HsfQWmwhtU9Hs04HXwltbZ/fDCvvnxUl+6icwUuGNd298O4abgfGtEUax7UMvTltJcOuErR9GhbuO/o2qL/JbDYFKhFdNVxRFBPIhIOHlkyu1tEUEJLwWJVNdyYeAhJdPrtTSFhEoJby7gYtbBEFdEYFUAkdGOogWni0E3QywV/cqIiACrxOwyR82SaJoiRbedcB2Rb2rngh0iMBrEX2V8CJgqaoITEZAwtP4EIEaCEh4NUBXSBGQ8DQGRKAGAhJeDdAVUgQkPI0BEaiBgIRXA3SFFAEJT2NABGogIOHVAF0hRUDC0xgQgRoISHg1QFdIEZDwNAZEoAYCEl4N0BVSBCQ8jQERqIGAhFcDdIUUAQlPY0AEaiAg4dUAXSFFQMLTGBCBGghIeDVAV0gRkPA0BkSgBgISXg3QFVIEJDyNARGogYCEVwN0hRQBCU9jQARqICDh1QBdIUVAwtMYEIEaCEh4NUBXSBGQ8DQGRKAGAhJeDdAVUgQkPI0BEaiBgIRXA3SFFAEJr88YuAB4ETgZuEVjRARGQEDCmwD1IOCknn+7BPg28OQI4MtldwlIeD25t2OjrwXeOWE83AUcCNgJtyoi4EFAwuuh+Bvg8wOo2nnuduU73YO6fHSegIQXhsDEW8xBI+M44NDODxsBSCUg4QGDbjEHwbUr4wHA06n0Zd9ZAhIeMNkt5qCR8dfw3GfPhCoiEEug88IreovZD+xLQXynxVJX/c4T6Lzw7Iq1beIwOB5YlOhD5t0i0HnhLQEWOOT8t8Be4cO7gzu5aDmBzgvP8rsSmOWQ6LuBbwB/dPAlF+0mIOGF/H4f+JFDrl8Oz32nOviSi/YSkPB6cruN4+yUE4CF7R036lkiAQlvAsC3Ag8B6ySCNfNLJ5kJ4+BeLjImIOENSN6FwB4Oib0H2BOw+Z4qIjBOQMKbZCx8E1jqMFZeAeYDv3DwJRftICDhDcnjR4A/O+X6ROAQJ19ykzcBCa9A/t4E3A58sEDdYVUuB3YZVkl/bz0BCS8ixT8Dvh5Rf1DVe8N3wyccfMlFngQkvMi8zQPOi7TpV/3V8PLGVrirdI+AhFci5x8G7ixh18/kWOBwJ19ykw8BCa9krt4AXA9sVdK+12w5MMfBj1zkQ0DCS8yVXbG+m+jDzO8DPg487+BLLppPQMJzyNHuwK8c/PwbmAlc4+BLLppNQMJzys8mwI3Amg7+7JnPrqQq7SUg4Tnn1p7XdnLwaW875zr4kYtmEpDwRpCXHwCLHfw+AHzAwY9cNI+AhDeinNjV6mIH3/8BtnCctubQJLlwICDhOUAc5MKuVlcCGzjEsJXtNnNGpR0EJLwK8nh+2I8lNZStbtgv1YnsG0FAwqsoDV5bS9i6Pps5o5I3AQmvwvzZuQy2eW5qsaTNAB5OdST72ghIeBWjnx5eumzqENe2E7SV8ir5EZDwasrZucCXHGLbGQ6nOPiRi2oJSHjV8l4l2mHAMQ7xbXc0m7Ctkg8BCa/mXO0M2C7Ub0xox+NhtowdpKKSBwEJrwF5mgZcBGye0JavAj9PsJdptQQkvGp5TxrtLGDvku2xKWpHlbSVWfUEJLzqmQ+MaFc8u/LZFTC2SHixxOqtL+HVy/9/0e0Np73pLFs+GnZCK2svu2oJSHjV8u4bzQ5LsZktZYttPWjCU8mHgIRXY65WC7eWX0hsg24zEwHWYC7h1QDdQm4M2OTpzRLjnwR8J9GHzKsnIOFVz5xdgTMdtom4GfhkDe1XyHQCEl46wygPXrNVXgCmREVW5SYRkPAqzIZ94PZYT3cDsHWF7VYofwISnj/T//O4fri13N4h1smAHR+mkjcBCW/E+dsxbNmwoUMcOzDlNAc/clE/AQlvhDmwfVKWAfbZILXYSxR7maLSDgIS3ojy+BNgkYPvpwC7Wr7o4EsumkNAwnPOxdRwa7mbg19bY2dr7VTaR0DCc8ypHTpit5Ypy3vGm7MEONCxbXLVLAISnlM+9gCWAu928Lc/cIaDH7loLgEJzyE3dkyXxyEj9hz3aeBWhzbJRbMJSHgJ+bHDKe3Wcn6Cj3FTOxfddh57xcGXXDSfgIRXMkf2ptFE99mS9r1mVzidMOTQFLmoiICEVwL0dsCpYVPZEuarmGh1QSrBPO0lvMi87QvYGQYeZR/gbA9H8pEdAQkvImW2mdCREfUHVbWP4rOBOxx8yUWeBCS8Anl7e3i9b58MUosd12wrC2LAp8aUffMIxOR/sc05jDG4DrDnoZyLnW1uZ9yt69AJW3E+z8GPXORPIEZHnROe3Q7+zinHRwNHOPmSm/wJSHgDcngo8GOH/NpHcZuJ8ksHX3LRHgISXp9cXgrs4pBj+yi+O6AzDRxgtsyFhNeT0LWA+wH7nVr0UTyVYLvtJbyQX1spfpVTrm1GywInX3LTTgISXjjsw+P7nA2RhcAJ7Rwr6pUjgc4LzzYPsi0aUot9FLer3CWpjmTfCQKdFp7XTBT7KG5vLu1liooIFCEg4RWhNEkdfRRPBNhR804LbzrwYELi9VE8AV7HTTstPMt9mdXj9lHcnue0PUPH1ZPQ/c4Lz9jZKaxFdwWz5zgT3TUJ0GUqAhJeGAMPh/0rJxsS9lHcRPeIxo0IJBKQ8ALAjcKslUE89VE8caTJfBUCEl4Pjr3CYZETx0gbPopvC9hPG8tjwNPAiow6J+FNSJZtx2CHRlpZGTY0Wp5RQvs11WulRdMxTAMebXojQ/skvD6J2hlYA7gwkyQOa+a1Lb7a9fbdFl3b4uscioSXQ5YS2yjhJQIcgbmENwKoTXMp4TUtI3FbqHRu64fmpatciyS8ctxGaaUr3ijpNsS3hNeQRPQ0Q8JrXk7cWyThuSNNdijhJSNsvgMJr3k5kvCalxP3Fkl47kiTHUp4yQib70DCa16OJLzm5cS9RXay0dfcvTbP4QzgoeY1q2+LJLxMEpXSTJujaVtTrJPipOG2doruooa3sbd5El5GyVJT20NAwmtPLtWTjAhIeBklS01tDwEJrz25VE8yIiDhZZQsNbU9BCS89uRSPcmIgISXUbLU1PYQkPDak0v1JCMCEl5GyVJT20NAwmtPLtWTjAhIeBklS01tDwEJrz25VE8yIiDhZZQsNbU9BCS89uRSPcmIgISXUbLU1PYQkPDak0v1JCMCEl5GyVJT20FgPeDxiK5oQ9sIWKoqAoMI7AhcFYFHwouApaoiMIjAfOCUCDzRwrN9MLaICKCqItAFAqeHPXCK9jVaeC8DUwD7rSICIgA7AFdHgogWnvnfErgpMpCqi0AbCawJnAPsEtm5UsKzh8jvAbdFBlN1EWgTgVnAScDGJTpVSnjjcZ4DngWeKRFYJiKQI4G3AWsBU8NP2T4kCa9sUNmJQNcJjAnvJeDNXSeh/otAhQTGhPcI8P4KgyqUCHSdwJjwbgQ+1XUS6r8IVEhgTHgXA3MrDKpQItB1Ageb8JYAC7pOQv0XgQoJzDPhHQAsqzCoQolA1wnMNOFtAtzddRLqvwhUSGCKCc/KZcCcCgMrlAh0lcAKYPa48HYGLu8qCfVbBCoksDvw63HhWdzdwvOeHfOrIgIi4E9gTHTmtld442FsPpod+j49/KzuH18eRaAzBP4e3qHcD9j85rHST3idIaKOikBdBCS8usgrbqcJSHidTr86XxeB/wKZgr12yqTi+QAAAABJRU5ErkJggg=="
insert({ icon: icon, name: "terminal", dblclick: () => { terminal(); } })
historyCmd = [];
historyCmdIndex = 0;
terminalIndex = 0;
terminal = () => {
    new Window({
        "title": "终端",
        "content": `
            <pre id="terminalLog" style="height: 94%;overflow-y: auto;word-break: break-all;"></pre>
            <input type="text" id="cmd" style="height: calc(5% - 4px);width: calc(100% - 4px)" />
        `
    });
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "Terminal",
        "msg": "listen 0"
    }));
    document.getElementById("cmd").addEventListener("keydown", (e) => {
        console.log(e)
        if (e.key == "Enter") {
            cmd = document.getElementById("cmd").value;
            if(cmd == "clear"){
                document.getElementById("terminalLog").innerHTML = "屏幕已清空";
                socket.send(JSON.stringify({
                    "type": "ptp",
                    "obj": "Terminal",
                    "msg": cmd
                }));
            }
            else {
                socket.send(JSON.stringify({
                    "type": "ptp",
                    "obj": "Terminal",
                    "msg": cmd
                }));
            }
            historyCmd.push(document.getElementById("cmd").value);
            historyCmdIndex = historyCmd.length;
            document.getElementById("cmd").value = "";
        }
        else if(e.key == "ArrowUp"){
            if(historyCmdIndex > 0){
                historyCmdIndex--;
                document.getElementById("cmd").value = historyCmd[historyCmdIndex];
            }
        }
        else if(e.key == "ArrowDown"){
            if(historyCmdIndex+1 < historyCmd.length){
                historyCmdIndex++;
                document.getElementById("cmd").value = historyCmd[historyCmdIndex];
            }
            else if(historyCmdIndex+1 == historyCmd.length){
                historyCmdIndex++;
                document.getElementById("cmd").value = "";
            }
        }
    });
    messageListen.terminal = (event) => {
        if (typeof (event.data) != "object") {
            // console.log(event.data)
            data = JSON.parse(event.data);
            if (data.type == "ptp" && data.obj == "terminal") {
                replaceList = (t) => {
                    t = t.replace(/\u001b\[33m/gi, "");
                    t = t.replace(/\u001b\[2J/gi, "");
                    t = t.replace(/\u001b\[H/gi, "");
                    t = t.replace(/\u001b\[m/gi, "");
                    t = t.replace(/\u001b\[\?25h1/gi, "");
                    t = t.replace(/\u001b\[\?25h/gi, "");
                    t = t.replace(/\u001b\[9X/gi, "");
                    t = t.replace(/\u001b\[50X/gi, "");
                    t = t.replace(/\u001b\[K/gi, "");
                    t = t.replace(/\u001b\[25l/gi, "");
                    t = t.replace(/\u001b\[10;3H/gi, "");
                    t = t.replace(/\u001b\[7;3H/gi, "");
                    t = t.replace(/\u001b\[12;3H/gi, "");
                    t = t.replace(/\u001b\[K/gi, "");
                    t = t.replace(/\u001b\[8;3H/gi, "");
                    t = t.replace(/\u001b\[10;3H/gi, "");
                    t = t.replace(/\u001b\[47X/gi, "");
                    while (t.match(/\r\n\r\n/) != null) t = t.replace(/\r\n\r\n/gi, "\r\n");
                    t = t.replace(/\r\n/gi, "<br/>");
                    t = t.replace(/\n/gi, "<br/>");
                    t = t.replace(/\r/gi, "<br/>");
                    t = t.replace(/\u0007/gi, "<br/>");
                    t = t.replace(/\u001b\]0;/gi, "<br/>");
                    return t;
                }
                document.getElementById("terminalLog").innerHTML += replaceList(data.msg) + "<br/>";
            }
        }
    };
}
