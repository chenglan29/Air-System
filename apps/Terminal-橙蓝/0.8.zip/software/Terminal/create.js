module.exports = () => {
    var a = global.terminal.length;
    global.terminalLog.push(``);
    if (process.platform == 'win32') {
        const pty = require('node-pty');
        global.terminal.push(pty.spawn('C:\\Windows\\System32\\cmd.exe'));
    }
    else {
        const { spawn } = require('child_process');
        global.terminal.push(spawn("true"));
    }
    global.terminal[a].onData((m) => {
        global.terminalLog[a] += m.toString();
    });
}