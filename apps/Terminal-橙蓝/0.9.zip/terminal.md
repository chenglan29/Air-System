# 编译
使用terminal前需要编译
具体过程如下：

1.安装好 Python(3.8.10) 和 Visual C++(2019)

2.使用 Visual Studio Installer 安装 Visual Studio Community(2022)，

工作负载选择“使用C++的桌面开发”，

在单个组件选择“MSVC v143-VS 2022 C++ x64/x86 Spectre 缓解库(最新)”和

“MSVC v143-VS 2022 C++ x64/x86生成工具（最新）”

3.在 server/ 打开命令行

4.输入 npm i node-gyp -g

这步为 全局安装node-gyp

5.输入 cd node_modules/node-pty

6.输入 node-gyp configure

7.输入 node-gyp build

8.等待编译完成即可
括号内为参考版本，其它版本可能适用
# 命令
下面的命令不会经过系统内，仅由面板处理
## clear
清理日志
### listen <索引>
切换不同的终端
### create
创建新的终端
### list
列出终端个数
### kill
删除当前终端