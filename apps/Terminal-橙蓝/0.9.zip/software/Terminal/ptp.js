const socketErrMessage = require("../../modules/socketErrMessage");
const socketMessage = require("../../modules/socketMessage");
module.exports = (data, socket, logger) => {
    if (data.msg.split(" ")[0] == "listen") {
        if(socket.level != "root" && socket.level != "admin")return socket.send(socketErrMessage("权限不足"));
        else if(socket.index >= global.terminal.length || socket.index < 0)return socket.send(socketErrMessage("该终端不存在，请监听其它借口"));
        else if(global.terminal[socket.index] == false)return socket.send(socketErrMessage("该终端已被删除，请监听其它借口"));
        socket.index = data.msg.split(" ")[1];
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": `+-----监听频道调整为 ${socket.index}-----+`
        }));
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": global.terminalLog[socket.index]
        }));
        // 监听标准输出的实时数据
        global.terminal[socket.index].onData((m) => {
            if (socket.index == data.msg.split(" ")[1]) {
                socket.send(JSON.stringify({
                    "type": "ptp",
                    "obj": "terminal",
                    "msg": m.toString()
                }));
                // console.log(`实时输出: ${data}`);
            }
        });
    }
    else if(socket.index >= global.terminal.length || socket.index < 0)return socket.send(socketErrMessage("该终端不存在，请监听其它借口"));
    else if(global.terminal[socket.index] == false)return socket.send(socketErrMessage("该终端已被删除，请监听其它借口"));
    else if (data.msg == "create") {
        if(socket.level != "root")return socket.send(socketErrMessage("权限不足"));
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": `+-----创建了一个新的终端，索引 ${global.terminalLog.length}-----+`
        }));
        require("./create")();
    }
    else if (data.msg == "list") {
        if(socket.level != "root" && socket.level != "admin")return socket.send(socketErrMessage("权限不足"));
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": `+-----共有 ${global.terminalLog.length} 个终端-----+`
        }));
    }
    else if (data.msg == "clear") {
        if(socket.level != "root")return socket.send(socketErrMessage("权限不足"));
        global.terminalLog[socket.index] = "+-----屏幕已清空-----+\n";
    }
    else if (data.msg == "kill") {
        if(socket.level != "root" && socket.level != "admin")return socket.send(socketErrMessage("权限不足"));
        global.terminal[socket.index].kill();
        global.terminal[socket.index] = false;
        global.terminalLog[socket.index] += `+-----该终端已被删除，请监听其它借口-----+`;
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": `+-----该终端已被删除，请监听其它借口-----+`
        }));
    }
    else {
        if(socket.level != "root")return socket.send(socketErrMessage("权限不足"));
        global.terminal[socket.index].write(data.msg + '\r\n');
    }
}