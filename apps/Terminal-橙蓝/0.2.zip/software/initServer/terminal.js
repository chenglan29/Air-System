const { spawn } = require('child_process');
const pty = require('node-pty');
module.exports = () => {
    global.terminal = undefined;
    global.terminalLog = ``;
    if (process.platform == 'win32') global.terminal = pty.spawn('C:\\Windows\\System32\\cmd.exe');
    else global.terminal = spawn("true");
    global.terminal.onData((m) => {
        global.terminalLog += m.toString();
    });
}