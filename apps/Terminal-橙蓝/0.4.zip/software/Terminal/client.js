terminal = () => {
    new Window({
        "title": "终端",
        "content": `<pre id="terminalLog" style="height: 94%;overflow-y: auto;word-break: break-all;"></pre><input type="text" id="cmd" style="height: calc(5% - 4px);width: calc(100% - 4px)" />`
    });
    socket.send(JSON.stringify({
        "type": "ptp",
        "obj": "Terminal",
        "msg": "create"
    }));
    document.getElementById("cmd").addEventListener("keydown", (e) => {
        if (e.key == "Enter") {
            cmd = document.getElementById("cmd").value;
            socket.send(JSON.stringify({
                "type": "ptp",
                "obj": "Terminal",
                "msg": cmd
            }));
            document.getElementById("cmd").value = "";
        }
    });
    socket.onmessage = (event) => {
        if (typeof (event.data) != "object") {
            console.log(event.data)
            data = JSON.parse(event.data);
            if (data.type == "ptp" && data.obj == "terminal") {
                replaceList = (t) => {
                    t = t.replace(/\u001b\[33m/gi, "");
                    t = t.replace(/\u001b\[2J/gi, "");
                    t = t.replace(/\u001b\[H/gi, "");
                    t = t.replace(/\u001b\[m/gi, "");
                    t = t.replace(/\u001b\[\?25h1/gi,"");
                    t = t.replace(/\u001b\[\?25h/gi, "");
                    t = t.replace(/\u001b\[9X/gi, "");
                    t = t.replace(/\u001b\[50X/gi, "");
                    t = t.replace(/\u001b\[K/gi, "");
                    t = t.replace(/\u001b\[25l/gi, "");
                    t = t.replace(/\u001b\[10;3H/gi,"");
                    t = t.replace(/\u001b\[7;3H/gi,"");
                    t = t.replace(/\u001b\[12;3H/gi,"");
                    t = t.replace(/\u001b\[K/gi,"");
                    t = t.replace(/\u001b\[8;3H/gi,"");
                    t = t.replace(/\u001b\[10;3H/gi,"");
                    t = t.replace(/\u001b\[47X/gi,"");
                    while (t.match(/\r\n\r\n/) != null) t = t.replace(/\r\n\r\n/gi, "\r\n");
                    t = t.replace(/\r\n/gi, "<br/>");
                    t = t.replace(/\n/gi, "<br/>");
                    t = t.replace(/\r/gi, "<br/>");
                    t = t.replace(/\u0007/gi, "<br/>");
                    t = t.replace(/\u001b\]0;/gi, "<br/>");
                    return t;
                }
                document.getElementById("terminalLog").innerHTML += replaceList(data.msg) + "<br/>";
            }
        }
    };
}
