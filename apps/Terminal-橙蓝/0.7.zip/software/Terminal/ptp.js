module.exports = (data, socket,logger) => {
    if (data.msg.split(" ")[0] == "listen") {
        socket.index = data.msg.split(" ")[1];
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": `+-----监听频道调整为 ${socket.index}-----+`
        }));
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": global.terminalLog[socket.index]
        }));
        // 监听标准输出的实时数据
        global.terminal[socket.index].onData((m) => {
            if(socket.index == data.msg.split(" ")[1]){
                socket.send(JSON.stringify({
                    "type": "ptp",
                    "obj": "terminal",
                    "msg": m.toString()
                }));
                // console.log(`实时输出: ${data}`);
            }
        });
    }
    else if (data.msg == "create") {
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": `+-----创建了一个新的终端，索引 ${global.terminalLog.length}-----+`
        }));
        require("./create")();
    }
    else if(data.msg == "list"){
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": `+-----共有 ${global.terminalLog.length} 个终端-----+`
        }));
    }
    else if(data.msg == "clear"){
        global.terminalLog[socket.index] = "+-----屏幕已清空-----+\n";
    }
    else global.terminal[socket.index].write(data.msg + '\r\n');
}