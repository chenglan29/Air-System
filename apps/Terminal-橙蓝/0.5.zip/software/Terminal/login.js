const fs = require("fs");
module.exports = (data,socket) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./software/Terminal/client.js").toString()
    }));
    // socket.send(fs.readFileSync("./software/login/desktop/result.png"), { binary: true });
}