module.exports = (data, socket,logger) => {
    if (data.msg == "create") {
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "msg": global.terminalLog
        }));
        // 监听标准输出的实时数据
        global.terminal.onData((m) => {
            socket.send(JSON.stringify({
                "type": "ptp",
                "obj": "terminal",
                "msg": m.toString()
            }));
            // console.log(`实时输出: ${data}`);
        });
    }
    else global.terminal.write(data.msg + '\r\n');
}