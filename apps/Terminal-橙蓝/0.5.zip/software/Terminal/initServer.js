
module.exports = () => {
    global.terminal = undefined;
    global.terminalLog = ``;
    if (process.platform == 'win32') {
        const pty = require('node-pty');
        global.terminal = pty.spawn('C:\\Windows\\System32\\cmd.exe');
    }
    else {
        const { spawn } = require('child_process');
        global.terminal = spawn("true");
    }
    global.terminal.onData((m) => {
        global.terminalLog += m.toString();
    });
}