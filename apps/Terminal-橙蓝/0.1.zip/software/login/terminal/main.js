terminalIndex = -1;
terminal = () => {
    new Window({
        "title":"终端",
        "content":`<div id="terminalLog" style="height: 95%;overflow-y: auto;word-break: break-all;"></div><input type="text" id="cmd" style="height: calc(5% - 4px);width: calc(100% - 4px)" />`
    });
    document.getElementById("cmd").addEventListener("keydown",(e)=>{
        if(e.key == "Enter"){
            cmd = document.getElementById("cmd").value;
            if(cmd.split(" ")[0] == "index"){
                terminalIndex = parseInt(cmd.split(" ")[1]);
            }
            else {
                socket.send(JSON.stringify({
                    "type": "ptp",
                    "obj":"cmd.js",
                    "index":terminalIndex,
                    "msg":cmd
                }));
            }
            document.getElementById("cmd").value = "";
        }
    });
    socket.onmessage = (event) => {
        if (typeof(event.data) != "object") {
            data = JSON.parse(event.data);
            if (data.type == "ptp" && data.obj == "terminal"){
                document.getElementById("terminalLog").innerHTML += data.msg + "<br/>";
            }
        }
    };
}
