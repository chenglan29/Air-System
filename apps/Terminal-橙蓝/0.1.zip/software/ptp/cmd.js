const { spawn } = require('child_process');
const pty = require('node-pty');
// const service1Logger = createLogger('logs/service1', 'app.log');
// const service2Logger = createLogger('logs/service2', 'debug.log');
// const fs = require("fs");
// if (process.platform == 'win32') global.terminal = spawn("cmd");
// else global.terminal = spawn("true");
module.exports = (data, socket) => {
    if (data.msg == "create") {
        var index = global.terminal.length;
        if (process.platform == 'win32') global.terminal.push(pty.spawn('C:\\Windows\\System32\\cmd.exe'));
        else global.terminal.push(spawn("true"));
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "terminal",
            "index": -1,
            "msg": `新的终端创建成功，索引: ${index} （在使用之前输入“index ${index}”以设置）`
        }));
        // 监听标准输出的实时数据
        global.terminal[index].onData((m) => {
            socket.send(JSON.stringify({
                "type": "ptp",
                "obj": "terminal",
                "index": index,
                "msg": m.toString()
            }));
            // console.log(`实时输出: ${data}`);
        });
    }
    else {
        global.terminal[data.index].write(data.msg + '\r\n');
    }
    // global.terminal.stdin.write('指令2\n');
    // // 监听错误输出
    // global.terminal.stderr.on('data', (m) => {
    //     // console.error(`错误信息: ${data}`);
    // });
    // 向子进程发送输入
    // global.terminal.stdin.write('指令1\n');
    // global.terminal.stdin.write('指令2\n');

    // 结束输入
    // global.terminal.stdin.end();

    // 监听子进程退出
    // global.terminal.on('close', (code) => {
    //     // console.log(`子进程退出码: ${code}`);
    // });
    // console.log(data)
    // socket.send(JSON.stringify({
    //     "type":"eval",
    //     "script":fs.readFileSync("./software/login/client_script/1.js").toString()
    // }));
    // socket.send(JSON.stringify({
    //     "type":"eval",
    //     "script":fs.readFileSync("./software/login/client_script/2.js").toString()
    // }));
    // socket.send(fs.readFileSync("./software/login/desktop/result.png"), { binary: true });
}