module.exports = () => {
    global.terminal = [];
    global.terminalLog = [];
}