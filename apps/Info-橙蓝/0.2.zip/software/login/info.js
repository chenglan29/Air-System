const fs = require("fs");
const os = require('os');
module.exports = (data,socket) => {
    setTimeout(()=>{
        socket.send(JSON.stringify({
            "type":"eval",
            "script":fs.readFileSync("./software/login/info/main.js").toString()
        }));
        socket.send(JSON.stringify({
            "type": "ptp",
            "obj": "info",
            "g":"init",
            "msg": {
                arch:os.arch(),
                constants:os.constants,
                cpus:os.cpus(),
                endianness:os.endianness(),
                homedir:os.homedir(),
                hostname:os.hostname(),
                // loadavg:os.loadavg(),
                networkInterfaces:os.networkInterfaces(),
                platform:os.platform(),
                release:os.release(),
                tmpdir:os.tmpdir(),
                totalmem:os.totalmem(),
                type:os.type(),
                userInfo:os.userInfo()
            }
        }));
        setInterval(()=>{
            socket.send(JSON.stringify({
                "type": "ptp",
                "obj": "info",
                "g":"float",
                "msg": {
                    loadavg:os.loadavg(),
                    freemem:os.freemem()
                }
            }));
        },1000)
    },100)
    
}