info = undefined;
var makingTemp = ``;
messageListen.info = (event) => {
    if (typeof (event.data) != "object") {
        data = JSON.parse(event.data);
        console.log(data);
        if (data.type == "ptp") {
            if (data.obj == "info") {
                if (data.g == "init") {
                    info = data.msg;
                    makingTemp += `CPU架构: ${info.arch}<br/>`;
                    makingTemp += `CPU核信息:<br/>`;
                    info.cpus.forEach(item => {
                        makingTemp += `${item.model} (speed:${item.speed})<br/>`;
                    });
                    inittime = info.inittime;
                    makingTemp += `主机名: ${info.hostname}<br/>`;
                    makingTemp += `操作系统: ${info.platform}<br/>`;
                    makingTemp += `操作系统版本: ${info.release}<br/>`;
                    makingTemp += `内存: <span id="info_mem1">0</span>B被占用/总共${info.totalmem}B<br/>`;
                    makingTemp += `(<span id="info_mem2">0</span>KB被占用/总共${info.totalmem / 1024}KB)<br/>`;
                    makingTemp += `(<span id="info_mem3">0</span>MB被占用/总共${info.totalmem / 1024 / 1024}MB)<br/>`;
                    makingTemp += `(<span id="info_mem4">0</span>GB被占用/总共${info.totalmem / 1024 / 1024 / 1024}GB)<br/>`;
                    makingTemp += `<table style="color: #08C;"><tbody>`
                    info.networkInterfaces.WLAN.forEach((item, index) => {
                        makingTemp += `<tr><td>WLAN ${index + 1}</td></tr>`;
                        makingTemp += `<tr>`;
                        makingTemp += `<td>地址:</td>`;
                        makingTemp += `<td>${item.address}</td>`;
                        makingTemp += `</tr>`;

                        makingTemp += `<tr>`;
                        makingTemp += `<td>网络协议(family):</td>`;
                        makingTemp += `<td>${item.family}</td>`;
                        makingTemp += `</tr>`;

                        makingTemp += `<tr>`;
                        makingTemp += `<td>是否为内部网络(internal):</td>`;
                        if (item.internal == true) makingTemp += `<td>是</td>`;
                        else makingTemp += `<td>否</td>`;
                        makingTemp += `</tr>`;

                        makingTemp += `<tr>`;
                        makingTemp += `<td>mac:</td>`;
                        makingTemp += `<td>${item.mac}</td>`;
                        makingTemp += `</tr>`;

                        makingTemp += `<tr>`;
                        makingTemp += `<td>子网掩码:</td>`;
                        makingTemp += `<td>${item.netmask}</td>`;
                        makingTemp += `</tr>`;

                        makingTemp += `<tr>`;
                        makingTemp += `<td><hr/></td>`;
                        makingTemp += `</tr>`;
                    });
                    makingTemp += `<tbody></table>`
                    makingTemp += `<progress value="0" id="info_mem5" max="${info.totalmem}"></progress><br/>`;
                    makingTemp += `服务器启动时长 <span id="runtime">${(new Date().getTime() - inittime) / 1000 / 60}</span>min<br/>`;
                }
                if (data.g == "float" && document.getElementById("info_mem1")) {
                    document.getElementById("info_mem1").innerHTML = info.totalmem - data.msg.freemem;
                    document.getElementById("info_mem2").innerHTML = (info.totalmem - data.msg.freemem) / 1024;
                    document.getElementById("info_mem3").innerHTML = (info.totalmem - data.msg.freemem) / 1024 / 1024;
                    document.getElementById("info_mem4").innerHTML = (info.totalmem - data.msg.freemem) / 1024 / 1024 / 1024;
                    document.getElementById("info_mem5").value = (info.totalmem - data.msg.freemem);
                    document.getElementById("runtime").innerHTML = (new Date().getTime() - inittime) / 1000 / 60;
                }
            }
        }
    }
};
insert({
    icon: "",
    name: "信息",
    icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAAGTNJREFUeF7tXQusZlV1Xl8UqEQHRQQqYhRQFCGC0JanDE+BpLxSeVUUWjVaaApSqFCBAq34AjGCGqWVR3UcJ3EAE3CEAYQRtD7AiFXkZRy1QC0yaLSAZvV8M/uf/nPnv/ees/Y65z+PtZI/9+bevdbee+39/fu1HpCg0EBoYFYNIHQTGggNzK6BAEjMjtDAHBoIgMT0CA0EQGIOhAZsGogVxKa34BqIBgIgAxno6KZNAwEQm96CayAaCIAMZKCjmzYNBEBseguugWggADKQgY5u2jQQALHpLbgGooEASIMDraobiciC9Nlk7PfR3/iT9NSEz6rR3wA83WCzB11VAMR5+FV1UxF5lYhsN/Zz9Dv/50FPiMgDIvJg+ox+fwAA/xfkpIEASIYiVXUDEdlHRN4kIvsmQHiBwNqyEXi+JiLLROROAM9ahQ2dLwBScQao6q4isreI7C8ih4jIhhVFNF38GRH5iojcKiIrAHyn6QZ0ub4AyDyjl84NR4rIwQkYr+7ygIvIjwkUEfmqiFwX55m5RzMAMot+VJWrxFEiQnBs03FQzNb8hwkSEVkKgKAJmqGBAMiYQlSVQCAgCAwCZEhEgCxNqwqBEyQiARARUVUC4tgEDl7FDpl4hcxVZTEAAmbQNFiApLPFW0WEn6GtFmUnPVeVa/gZ6lllcABR1a0SKAiM15SdKQMv96MxoPx8SLoYDEBU9fVjwNhsSIPs2NdfjgHle45yWyuq9wBR1ReIyNnp09qB6GDDLhaRiwH8uoNtL93kXgNEVXnwJji4egT5a4CrCEGy2F90OyT2EiCqyrMFgcFzRlD9GuBBnkDhWaVX1DuAqOp7EjjinNHsVOX5hCC5tNlq662tNwBR1b2Kd50LCuO8A+pVWZb0lSLykIj8ao4PK3jRHJ9tRWTrrFbUy7y8eFo6H8DX662mGem9AIiqniIiHyo+GzejtjlrebKw7r07AYFgWPvxektIbzgEyszPHiLywhbo4LcichaAK1rQlqwmdBogqspvWgLj7VlayGMmIG4XEZqX3wHgu3ni8rhV9Q2F5e4bk/n9wikD5soEFK6YnaTOAkRV90vg2G0Kmr83mWPwpZn+FjQpbx2pKk3x6a/CzxFFm3eeQiO/nUBy2xTqzq6ykwBJB3GuHM/J1kB5AY8mUFwPgP4VnSNVpf8KgUKDzC0b7MAfEkg6d4DvHEAKi1teKZ7Y4ODScO/6ZOXK7VTnSVV5TiFIRmBpqk/XAujU1XunAKKqN4rIoQ2MJoFwlYhcDYDbqd6SqnLb9TYROamh88pNAA7rikI7AxBV5bXhnjUr9icEBcEBgL8PhlT1FQkkBAt/r5PuAsBr+dZTJwCiqt8XkR1r1CZXiREwerGNsuoqbb+4mhAodR7q7wOwk7WdTfG1HiCq+tMaH8Z+LyIXArioKYV3qR5VPVdEzhOR59bU7pUAXl6TbBexrQaIqvLbnAHW6iCGxLmoLy++dSiIMpOFAoHC0EZ10CoAbXjcnNi31gJEVbWO0RARmmcTGB+uSX4vxarqmSJCoNB9wJ0AtHIutrJRqvqYiGzuPgprrmu5pZrqa3cN/WpEZHql55aL18Pe9DiALbyF5sprHUBqPJCfF2eN3Omyhj+dTS70kbaOlNYd3FsFkCIW1S01WOPSR4GGc1+uYUAHK1JV/zyZ+nj79S8vYnQd2BbFtgYgqvpFEXmzs2IWJXD8zFluiFuzkrwsgeR4Z4UsAXCMs0yTuFYApCZwcNWIg7hpWlRjSgd42sZ5UitAMnWA1GRbdQyAJZ6jFbLm1oCqcvXnLsCTpm67NVWAJKvcSzw1KiIBDmeFlhVXE0jOmKYb79QAkvw5bnY2WT8QAF0+g6akAVWlyzMvW7yIpvIHAZiKP8lUAJI8ARl+39PZ6bV9jKrhNcualJOiyvzQsU46XR0MoHHPxGkB5DPObrIL+h7AzHGyNSIqBexjrkUvuhLAO7yElZXTOEBSgIXLyzawRLmNAfyuRLko0rAGVPV5xTU7Azh40alNB4JoFCDJ8I1bK6/oI1sB+IWX9kOOvwZU9aUi4hXwmmDjVquxkEJNA8TzpXwnAPf5D2lI9NaAqtKXhz49HtToS3tjAHG+0t0XwB0e2g4ZzWhAVRmKiKGRPKixq99GAJJuNe4UEY9woEcCoFVuUMc0oKq0AmYQjFximNN9mri1bAogdGf1iGYR5iO5U2vK/I5mKcx6RbfgWql2gKQUBF9w6MUiACc4yAkRU9aAqn5eRDwMHI+rO/VCrQBJd+HcWuXm56DJOl9Te2eVq6qvFJHD06MprWNJ7Ccfx24oviUfmfJ8dq8+WQHTiiLXVJ75SbjVqi2JT90Aeb9TZqfD++bPoao8j31ARP56nhn4ryLyXgDcd/eGkj/JDQ4dYsqFcxzkTBRRG0BSTkCPoGu98wRM70HcZpSN6MHILic0ef9f14Qbl+vombgzgFpyJtYJEFrpMplNDjEOLkNk9oaSXzejwVcNfsBtxMK++dMXkR15q5Xr435psc06o45JUgtAUqplrh4517p9nRAMGLGLcTDvAcD0Br2hjC+McR1w+8lVxOvFfq3sugDC/IA8f+RQ7650VfXvRSTXy/FMAB/JUWzbeJ2ufs8BwMy7ruQOkJT9iKtHzg3FMgAM1d8rUlXexm2f2an7AeToNrP6ethVlSklcoLTUbdcRZ72bGEdAKFJ8qczGslwoNxrN2aQltHW0qzOPhK9831JFxc8m+WEOX0nALpSuFEdAOG7x94ZLezdrRV1oapHiciXMvQyzno0gKVOslojxuFWa0XhUcpsWm7kChCHSXBvYWdlPcC6KaUOQapKswjmHPGgkwDQfKd3VNhr3ZMZVd71y8MbIDQpOTZj1E4vAhlflsHfWlZHkxv2sXYTi2kpsghYfloRsPyjGfUvLowYj8vgX4fVDSBF+J5tiogi/1kkk9/I2DgmrNkFQC/zc6jqn4jIfxh1M5PtTwF8y0lWq8Sk/CRcRaxJfHhI36FI9fawR8c8AcJHwZwQPhcUAb7/yaNTbZWhqv8jIptmtu8JAC/OlNFq9iKwP+fB+RmNdPMX8QRIzuGcqwZXj16nPVNVbh24hcihywCcniOg7bwpHRxXEWveELfDugtAiqDTvLUiQKzU+0GnYlT1jwsz7/sNZiYjvdK6YHsA/2VVdFf4HL5MaOXLPPZZ5AWQXLsrrh4eho1ZymiCWVX/UkT+3VjXWwB8zsjbKbaUfZeriJVc7LOyAZJeznk45yHdQtcVlph8IxgMqerfiMgVFTt8CoBPVOTpdPHCIpxvPVZjVR7SeVjPeln3AAivdXM8Bk8G4PU+0JkJoao0paFd1nzZexm5hfZXNMUYFKkqs+1+NqPT2dfhHgBhB9gRCz0qIjSb6OXVbhmFqOqJ6VuS18BbJ56VIsJrXK6u15aR08cy6cqXIUy3NPaP+e5PNvKuZvMACJcyuo1a6FMA3m1hDJ5haEBVPyki7zL29hEA1q1/PkBUdc/CVzzHqPDQIW4djIM9SLa0Fb0po/N7AbjLyp+1gqjq+5hS2Vh5b+2ujPoItlk0kGmfdS6Af7YqNxcgjExhTbjY+5dz66AE37oayHxZv6VwnTjIqlMzQFR1QxH5jYhsYKz8EADLjLzBNiANqCodqay3eM+KyPOLyCfPWFSWA5BDReRGS6VFMAfmjdg8947aWHewdUwD6a3tcRFZYGz6YQBM55gcgOS8nvfSpdY4eMFWQgOZLrnmV/UcgHxDRP6sRN8mFeml16BRF8FWQgOZ3obfLG5Ldy9RzXpFcgCSY7q9RxGUgQALCg2U0kCxgnCC312q8PqFzC4CJoCoKn0aCBALPQVgEwtj8AxbA6q6KuMc8mIAT1TVoBUg3FpZV4CbABxWtaFRPjSgqrwU4uWQhXYH8M2qjFaA5JhsXw7gb6s2NMqHBlT14yJyqlETJlcBK0ByXCJ7G5ihysClvH1/UZJnCYAflCzb22KZAR1MD9NWgNDhh6uIhXqXyqCqEopvQvqUV01nsFmx8lrPfVWb2MrymSkTPgfgLVU7ZgVIzhXv6wDQwWqwpKoLReS2igrYDwAjDw6WVHUHEbGupKarXitAcq54/2joL+gBEBvG04v6/9q4xXTVWxkgmY1cCaBs0hijHtrPFgCxj5GqMpnQyLGsqqDKX84WgLxERGgXY6HbAexnYewTTwDEPpqqyq0pt6gWov3ff1dhtABkWxF5sEolY2WXAjjayNsbtgCIfShVlQHArUE+tgPwUJXaLQBhhqPvVKlkrOy/AZgvaaVRdHfYAiD2sVJVJjX9K6OEXaumsLMAxHIDM+rPJQCYZWnQFACxD7+qMruWNR9h5ZtAC0CY0/t6YxffB+BfjLy9YQuA2IdSVf+xSLJjdaE9osjxWCn1tAUgfGyxhqIZXPCzSVMhAJIFEEvQvVGFJwKoFNXSApCcBjLX9yK7evrBGQCxj6OqHi8izDFvocpf0BaAvLfIAWLNJhphftYEsbac4yrvny0zqO08mWGAzgbwgSp9DIBU0ZZT2QCIXZFdAEhssezju5ozAGJXYBe2WHFIt49vACRfdzlf0I0c0uOaN3+Q4wxi1GEXrnktgztSRzwUxhbLCI01bF14KAxTk6whjjNIjvq6YGoSxoo5IxwrSJb2umCsGObuWUMcK0iO+rpg7r6RiFi9usJhKlaQHHzwDNJuh6l0UAqX24xhjncQm/IyvVmbcblNAImgDbYxjneQPL11JmhDhP3JG2jLVfngbbG6FPYnAscFQDI0YGPtUuC4CD1qG+PYYuXprTOhRyN4dd5AxxbLoL8uBa/OSX/wJIAXGfTTG5a4xbINpar+SkReaOOW5tIfOFz1Vo4uYVRKK9kCINWHRVVzTJxMV7xsZWWHqVHXCseVnKveQUd4D4CYAHKaiHy0OudqDlNc3lyAfFBEzjI2+DoA1uBfxirbwxYAqT4WqrpURI6szrma40MA/sHCm7OC7C8iyy2VisiTIrKFNXe1sc7WsAVAqg2Fqm4oIo9lnD8OAHBrtVrXlM4ByAYi8hsRYeMtdCAAK8As9bWGJwBSbShU9QARuaUa19rSz4jI8wE8a+E3A4SVqSoDyNHD0EKmjD+WitrGEwCpNiKqen7BwcdpC90A4AgLY9YKkgDyd8Wyd5mx8nsB7GLk7TRbAKTa8KnqPSKyczWutaVPK54VPmbktW+xEkB2FZFvWytnxtIiwftXMvg7yRoAKT9smWF+WNFuAKzB1vMAkkByfxHp7tXlu7xOyU8BeLeRt7NsAZDyQ6eqnxSRd5XnWKfkj4tIntsbeVezZZ1BEkBywtE/KiKvBcBbrcFQAKTcUKsqX81/KCJbluNYr1R2ug0PgBwrIl8wdoBsJwO4KoO/c6wBkHJDpqonichny5WeWOo4AIsz+F1WELrgMmvtNsaGDO7RMABSbqZkPg4+LCI75CaMzV5B0jbrEhF5T7luTyy1C4B7M/g7xRoAmX+4VJW3Vry9stKlAKyJdtbW6QWQvUXkTmtPeFUM4PQM/k6xBkDmHy5Vpd0V7a+stA+AFVbmEZ8LQNIqQoAQKBbiIZ2ryE8szF3jCYDMPWKq+oq0elhN21cUVhr7eMwLT4Bwi8WtlpUG87IeAJkXIDku3RR+BoBLrRNxnM8TIDyk87DOQ7uFuHpwFen9lW8AZPbpka52efbgKmKhp9PhnIf0bHIDSNpm8bqX175WGoSfSABkToDk+H1Q8GIAx1kn4Ew+b4DQx4OJ3q00CPusAMicAMmxu6LgowHQd8SFXAGSVpGcwzpFnAfgIpfetVRIAGTywKjquSJyYcawuR3OR22oAyDvEJFPZ3Ty9yKyEMDXM2S0mjUAsv7wqOpexbjfXuRAf27G4L0TwGcy+NdjrQMgPKTz0e81GQ1dBuCQDP5WswZAJgKEVt1vyhi4H9EkPvflvNYzyEi4qp5deBq+P6OzZD0LwIczZbSSPQCy7rCo6pn0G88crHMAWNOTz1q1+wqSziFbpVVks4xO/zpttb6bIaOVrAGQ/x+WFM6HW6sXZAzWL9Pq8fMMGRNZawFIAkmufRbFXF/YaFkjWXjryk1eAGQdgFxXvJqbXWKTJBe7q0kDXCdAXp9WkdyJ1btbrQDIminhcGs1mls8e3wvd6I1CpCkAJ5DeB7JpcMBfDlXSFv4VfV1InJfxfbsCOAHFXlaWzwzlcF4vy4uwkedU1dHa1tBEkC4r+S7CFeTHOINxUEAfpYjpE28yRnobSXbdHWfnMpU9WUicnPmTSdVx1WDVrs8r9ZCtQIkgSTX43DU8UUATqhFCyG0UQ2o6udF5HiHSrM9BudrQ+0ASSC5WkTeOl9jSvy/t1e/JfreiyJOV7rUxTUAyq7AZt01BRA+GnKrlXPtO+rkMQCWmHscjFPTgKq+ubC0/aJDA3ity60Vt961UiMASatIrr/IuCICJLVOC3/hjuBg49z8PebraWMASSBhfFXGWfWgwcb29VBekzIyY+vObOrywpX2wKba3zRAaJD21cKsYGOnDjKmVu3LrFNbBylGVbm9ZmwrD/qtiBzcpCFrowBJq8gpxVnkcg9tJRkL6rzmc2zn4ESpKq/5n3Ls+KkArnCUN6+oxgGSQEKT5LfP27ryBTYuEqT8rnzxKFm3BlT1eYXBKb/xvehKAHSlaJSmBRAm8eRWazfH3m4F4BeO8kKUUQOq+lIR8TQcZIB0bq2YxLNRmgpA0iqyX3pNfY5jj3cCUNWEw7H6EKWqO4rI9x018YdkRXGbo8zSoqYGkAQSz6vfUaf3BXBHaQ1EQTcNqOobReRrbgLXCGrsSndSu6cKkASSa0TkRGelHlkk52H2q6CGNFAkuaHJOk3XPelaAB4WGOY2TR0gCSQ3MpmOuReTGcMsxVmhs4lzNB8Zr+ImAIc11IVZq2kFQBJIGKRhT2eFLEquu72xAnbWT5a4ZJVLV1kPw8PxttwFgG9mU6fWACSBhIc7HvI8iQ+JXE1640/iqRyrrOTPQXDkBOeYVP19AHaytsubr1UASSD5qYhs7d3RIcTbqkFnE0U6egLOlL8SwMub6keZeloHkAQSxufdpEwHKpbhwf1CAL0LBFFRD6biKcDCeQ4+5JPqXwXAGs3d1J8yTK0ESAKJlumAoQy9zy7qa0ghgz5KsaSDOCMf5kQfmbUuAK2ci61s1EiLqvqYiGxeagSrF1qWgNLbCI7VVbI+R4p4SGDkBHWbqymPA9jCo611yGg1QNJKUsfBfaRLhjnllqvXsYCtEyedNbilygkHOlf1rTqQT2po6wGSQOLpRzJJDwyVSrfgq4aQn2SuGZvyczC7LN1ZmSewLmrUr8PaiU4AJIGErpp02ayTmMRnBJRBpIMb284yYc0IGNbkNWXHZgmAY8oWnma5zgCkQZCwKt6iMXc7w+30OvtuyibL1YLgaOIWqTPg4EToFEASSOqw3ZrrS4r2RbweZj73XqSHS9sohnSl/VSToV2nbltVdTXqHEASSGgFzFdcT1P5+XT3aDLGY7xghurvHKkqU0qMQLFlgx2gyTqtGVwSazbY7u6tIGN7ZvqTECSeTldldc9tF1eVu5n0xTsnRdlGzFdOVZmrZaGI7JGAUeehe7bm0NmJ4JiKP8d8Oprv/51cQcZAQs9EgsTTfXc+nc38P32uCRS+p9xcJP75RlUBnuVVdXc6GBVtobEfgbHAU35FWVcmcDTuCVixnbMW7zRAxoDCQBAEile0lBz9EjAEy0MzP14rTVoZthWRmR+CYpqAGOmNvuhcNRoNsJAzaLPx9gIg6VzCyXGBY9ytOvS9MoGG36izfVgvV8bZPgRFHcacXv1dXmQ2OL/J0DxeDZ8kpzcAGVtNeIBnygWPMKd16r5vshkOlKkIOncQn2sgegeQtJrQR4Egmaq7Zt8QMEd/ePVOcPQuiF8vATK2mjD1AoGSm59kQHO9UleZn4PAWFyJq0OFew2QtJrQPJsg8ch01aGhrb2pzChLcNSWvKb2HpSooPcAGVtNuIpwy8VPnE9KTI4JRXjO4HaKuTlqyQloa1Z9XIMByBhQmKJ6BBRvf+r6Rmq6knm2GAHDM2LidHtVovbBAWQMKHxlHgFl7xK6GmKRFWPAeHqIChgsQMYHW1WPKkL080BPwz0CZ8hEINBAczGApUNWBPseABmbAaq6TQIJATO0VYWrBQFBq+WHhw6MUf8DILPMBFUlQAgUrioETh+JQOBqsbTI2kSABM3QQABknimR7J4IEpqK71s4Ub2y47PokRRgmib7XC0GebYoO4YBkLKaSuVUleFR909gIWA2qCii6eLPJkAw6vqtAO5qugFdri8AkjF6qrphMo5kUkkaS75KRDbNEOnB+oSIPJAsihnsgsERnvEQPEQZARDnUVdVAoRA2W7s5+h3L/CMQPCgiPBDQKz+CYD/C3LSQADESZFlxKTzDP01+GFo1dHv4z8pij4lMz+rRn+Lc0MZbfuUCYD46DGk9FQDAZCeDmx0y0cDARAfPYaUnmogANLTgY1u+WggAOKjx5DSUw0EQHo6sNEtHw0EQHz0GFJ6qoEASE8HNrrlo4EAiI8eQ0pPNRAA6enARrd8NBAA8dFjSOmpBgIgPR3Y6JaPBv4PwyCIQZ1czvkAAAAASUVORK5CYII=",
    dblclick: () => {
        new Window({
            "title": "信息",
            "content": makingTemp
        });
    }
})