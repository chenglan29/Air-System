
module.exports = (versionNum, versionName, logger) => {
    global.inittime = new Date().getTime()
    
    setInterval(()=>{
        logger.info(`服务器运行时长: ${(new Date().getTime() - global.inittime) / 1000 / 60} min`)
    },60000)
}