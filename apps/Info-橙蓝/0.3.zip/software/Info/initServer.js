
module.exports = () => {
    global.inittime = new Date().getTime()
}