iconList = [
    [
        {icon:"",name:"百度",dblclick:()=>{new Window({"title":"百度","src":"http://m.baidu.com"});}}
    ],
    [
        {icon:"",name:"空",dblclick:()=>{new Window();}},
        0
    ]
];
for(var i = 0;i<iconList.length;i++){
    for(var j = 0;j<iconList[0].length;j++){
        RenderingIcon(i,j);
    }
}
