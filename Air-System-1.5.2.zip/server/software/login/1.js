const fs = require("fs");
module.exports = (data,socket) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./software/login/client_script/1.js").toString()
    }));
    socket.send(JSON.stringify({
        "type":"eval",
        "script":fs.readFileSync("./software/login/client_script/2.js").toString()
    }));
    // socket.send(fs.readFileSync("./software/login/desktop/result.png"), { binary: true });
}