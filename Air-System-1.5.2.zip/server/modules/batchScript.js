const fs = require("fs");
module.exports = (dir,data,socket) => {
    fs.readdirSync(dir).forEach(item=>{
        if(fs.statSync(`./${dir}${item}`).isFile())
            require(`../${dir}${item}`)(data,socket);
    });
}