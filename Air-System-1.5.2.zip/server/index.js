const WebSocket = require('ws');
const uuid = require('uuid')
const fs = require("fs");
const log4js = require("log4js");

const socketErrMessage = require("./modules/socketErrMessage");
const socketMessage = require("./modules/socketMessage");
const batchScript = require("./modules/batchScript");

var info = JSON.parse(fs.readFileSync("info.json").toString());
var userList = JSON.parse(fs.readFileSync("userDataBase.json").toString());

log4js.configure({
    appenders: {
        System : { type: "file", filename: `${info.log.outPath}${new Date().getTime()}.log` },
        Console : { type: "console" },
    },
    categories: { default: { appenders: ["System","Console"], level: "debug" } },
});
const logger = log4js.getLogger("System");

const server = new WebSocket.Server(
    { port: info.port },
    ()=>{
        logger.info(`服务器在 ${info.port} 端口开放`);
        batchScript("software/initServer/");
    }
);

server.on('connection', (socket) => {
    // 客户端连接时生成唯一 ID
    const clientId = uuid.v4();
    logger.info(`客户端 ${clientId} 已连接`);
    socket.doLogin = false;
    // 接收消息
    socket.on('message', (data) => {
        batchScript("software/getMessage/");
        logger.info(`收到消息：${data}`);
        if(data.length>1024*1024)socket.send(socketErrMessage("过大的数据"));
        try{
            var data = JSON.parse(data);
            if(data.type == "login"){
                if(!userList[data.username])return socket.send(socketErrMessage("不存在的用户名"));
                else if(userList[data.username].password != data.password)return socket.send(socketErrMessage("密码错误"));
                else {
                    socket.send(JSON.stringify({
                        "type":"Init",
                        "level":userList[data.username].level,
                        // "desktop":userList[data.username].desktop
                    }));
                    socket.doLogin = true;
                    batchScript("software/login/", data,socket);
                }
            }

            if(socket.doLogin){
                batchScript("software/getMessage_doLogin/", data,socket);
            }
            else return socket.send(socketErrMessage("未登录，无法进行其他操作"));
        }
        catch(e){
            logger.error(e);
        }
        // socket.send("?")
        // // 广播消息给所有客户端
        // server.clients.forEach(client => {
        //     if (client.readyState === WebSocket.OPEN) {
        //         client.send(`${clientId}: ${data}`);
        //     }
        // });
    });

    // 关闭连接
    socket.on('close', () => {
        console.log(`客户端 ${clientId} 已断开`);
        batchScript("software/closeConnection/");
    });
    batchScript("software/createConnection/");
});