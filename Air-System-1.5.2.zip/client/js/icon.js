//此文件用于显示桌面图标
//图标列表
//使用二位数组，横向长度依据[0].length，留空可用 0
iconList = [];

RenderingIcon = (top,left)=>{
    if(iconList[top][left] == 0)return;
    let icon = document.createElement("div");
    let iconImg = document.createElement("img");
    let iconName = document.createElement("div");
    icon.className = "icon";
    icon.style.top = top * 80 + "px";
    icon.style.left = left * 80 + "px";
    if(iconList[top][left].dblclick)icon.addEventListener("dblclick",iconList[top][left].dblclick);
    icon.addEventListener("click",()=>{
        document.querySelectorAll(".icon").forEach(item=>{
            item.style.background = "none";
        });
        icon.style.background = "rgba(0,127,255,0.2)";
    });
    iconImg.className = "iconImg";
    iconImg.src = iconList[top][left].icon;

    iconName.className = "iconName";
    iconName.innerHTML = iconList[top][left].name;

    icon.appendChild(iconImg);
    icon.appendChild(iconName);
    document.getElementById("desktop").appendChild(icon);
}

// for(var i = 0;i<iconList.length;i++){
//     for(var j = 0;j<iconList[0].length;j++){
//         RenderingIcon(i,j);
//     }
// }
