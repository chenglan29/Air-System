var versionNum = 9;
var versionName = "1.15.11";
const WebSocket = require('ws');
const uuid = require('uuid')
const fs = require("fs");
const log4js = require("log4js");

const socketErrMessage = require("./modules/socketErrMessage");
const socketMessage = require("./modules/socketMessage");
const batchScript = require("./modules/batchScript");

var info = JSON.parse(fs.readFileSync("info.json").toString());
var userList = JSON.parse(fs.readFileSync("userDataBase.json").toString());

log4js.configure({
    appenders: {
        System: { type: "file", filename: `${info.log.outPath}${new Date().getTime()}.log` },
        Console: { type: "console" },
    },
    categories: { default: { appenders: ["System", "Console"], level: "debug" } },
});
const logger = log4js.getLogger("System");

appList = [];
addApp = (name) => {
    if (fs.existsSync(`./software/${name}/index.json`) == true) {
        var item = JSON.parse(fs.readFileSync(`./software/${name}/index.json`).toString());
        appList.push(item);
        // logger.debug(item.UnavailableSystemVersions)
        if (item.UnavailableSystemVersions.indexOf(versionNum) != -1) logger.error(`软件 ${item.name} 的版本无法在本版本(${versionName})运行`)
        else if (item.AvailableSystemVersions.indexOf(versionNum) == -1) logger.error(`软件 ${item.name} 的版本不支持在本版本(${versionName})运行，可能会导致运行出错`)
    }
}
fs.readdirSync("./software/").forEach(item => {
    addApp(item);
});
//此处有一个检查软件依赖库的功能么有做

const sortByPriority = (arr) => {
    // 使用slice()创建副本避免修改原数组
    return arr.slice().sort((a, b) => a.priority - b.priority);
};

appList = sortByPriority(appList);


const server = new WebSocket.Server(
    { port: info.port },
    () => {
        logger.info(`服务器在 ${info.port} 端口开放`);
        //新的API
        appList.forEach(item => {
            item.event.initServer.forEach(_item => {
                require(_item)(versionNum, versionName, logger);
            })
        })
        //旧的API
        batchScript("software/initServer/", versionNum, versionName, logger);
        batchScript("debug/initServer/", versionNum, versionName, logger);
    }
);
server.on('error',(err)=>{
    logger.error(err);
})
server.on('connection', (socket) => {
    // 客户端连接时生成唯一 ID
    const clientId = uuid.v4();
    logger.info(`客户端 ${clientId} 已连接`);
    socket.doLogin = false;
    // 接收消息
    socket.on('message', (data) => {
        //新的API
        appList.forEach(item => {
            item.event.getMessage.forEach(_item => {
                require(_item)(data, socket, logger);
            })
        })
        //旧的API
        batchScript("software/getMessage/", data, socket, logger);
        batchScript("debug/getMessage/", data, socket, logger);
        logger.info(`收到消息：${data}`);
        if (data.length > 1024 * 1024) socket.send(socketErrMessage("过大的数据"));
        try {
            var data = JSON.parse(data);
            if (data.type == "login") {
                if (!userList[data.username]) return socket.send(socketErrMessage("不存在的用户名"));
                else if (userList[data.username].password != data.password) return socket.send(socketErrMessage("密码错误"));
                else {
                    socket.send(JSON.stringify({
                        "type": "Init",
                        "level": userList[data.username].level,
                        // "desktop":userList[data.username].desktop
                    }));
                    socket.doLogin = true;
                    //新的API
                    appList.forEach(item => {
                        item.event.login.forEach(_item => {
                            require(_item)(data, socket, logger);
                        })
                    })
                    //旧的API
                    batchScript("software/login/", data, socket, logger);
                    batchScript("debug/login/", data, socket, logger);
                }
            }

            if (socket.doLogin) {
                if (data.type == "ptp") {
                    // logger.debug(fs.readdirSync("."));
                    //新的API
                    appList.forEach(item => {
                        if (item.name == data.obj) {
                            item.event.ptp.forEach(_item => {
                                require(_item)(data, socket, logger);
                            });
                        }
                    })
                    //旧的API
                    if (fs.existsSync(`./debug/ptp/${data.obj}`) == true) require(`./debug/ptp/${data.obj}`)(data, socket, logger);
                    else if (fs.existsSync(`./software/ptp/${data.obj}`) == true) require(`./software/ptp/${data.obj}`)(data, socket, logger);
                }
                else {
                    //新的API
                    appList.forEach(item => {
                        item.event.getMessage_doLogin.forEach(_item => {
                            require(_item)(data, socket, logger);
                        })
                    })
                    //旧的API
                    batchScript("software/getMessage_doLogin/", data, socket, logger);
                    batchScript("debug/getMessage_doLogin/", data, socket, logger);
                }
            }
            else return socket.send(socketErrMessage("未登录，无法进行其他操作"));
        }
        catch (e) {
            logger.error(e);
        }
        // socket.send("?")
        // // 广播消息给所有客户端
        // server.clients.forEach(client => {
        //     if (client.readyState === WebSocket.OPEN) {
        //         client.send(`${clientId}: ${data}`);
        //     }
        // });
    });

    // 关闭连接
    socket.on('close', () => {
        console.log(`客户端 ${clientId} 已断开`);
        //新的API
        appList.forEach(item => {
            item.event.closeConnection.forEach(_item => {
                require(_item)(data, socket, logger);
            })
        })
        //旧的API
        batchScript("software/closeConnection/");
        batchScript("debug/closeConnection/");
    });
    //新的API
    appList.forEach(item => {
        item.event.createConnection.forEach(_item => {
            require(_item)(data, socket, logger);
        })
    })
    //旧的API
    batchScript("software/createConnection/");
    batchScript("debug/createConnection/");
});