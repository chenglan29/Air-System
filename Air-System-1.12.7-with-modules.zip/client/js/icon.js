//此文件用于显示桌面图标
//图标列表
//使用二位数组，横向长度依据最大横向长度，留空可用 0
iconList = [[]];

RenderingIcon = (top,left)=>{
    if(iconList[top][left] == 0 || iconList[top][left] == undefined)return;
    let icon = document.createElement("div");
    let iconImg = document.createElement("img");
    let iconName = document.createElement("div");
    icon.className = "icon";
    icon.style.top = top * 80 + "px";
    icon.style.left = left * 80 + "px";
    if(iconList[top][left].dblclick)icon.addEventListener("dblclick",iconList[top][left].dblclick);
    icon.addEventListener("click",()=>{
        document.querySelectorAll(".icon").forEach(item=>{
            item.style.background = "none";
        });
        icon.style.background = "rgba(0,127,255,0.2)";
    });
    iconImg.className = "iconImg";
    iconImg.src = iconList[top][left].icon;

    iconName.className = "iconName";
    iconName.innerHTML = iconList[top][left].name;

    icon.appendChild(iconImg);
    icon.appendChild(iconName);
    document.getElementById("desktop").appendChild(icon);
}

var iconListHeight = iconList.length;
var iconListWidth = 0;
for (var i = 0; i < iconListHeight; i++) {
    if (iconList[i].length > iconListWidth) iconListWidth = iconList[i].length;
}

insert = (icon) => {
    var iconListHeight = iconList.length;
    var iconListWidth = 0;
    for (var i = 0; i < iconListHeight; i++) {
        if (iconList[i].length > iconListWidth) iconListWidth = iconList[i].length;
    }
    var flag = 0;
    var investTop = -1;
    var investLeft = -1;
    for (var i = 0; i < iconListHeight; i++) {
        for (var j = 0; j < iconListWidth; j++) {
            if(flag == 0){
                if(!iconList[i][j] || iconList[i][j] == 0){
                    iconList[i][j] = icon;
                    investTop = i;
                    investLeft = j;
                    flag = 1;
                }
            }
        }
    }
    if(flag == 0){
        if(Math.floor(Math.random()*2) == 0){
            iconList[0].push(icon);
            investTop = 0;
            investLeft = iconListWidth;
            iconListWidth++;
        }
        else {
            iconList.push([icon]);
            investLeft = 0;
            investTop = iconListHeight;
            iconListHeight++;
        }
    }
    RenderingIcon(investTop,investLeft)
}
