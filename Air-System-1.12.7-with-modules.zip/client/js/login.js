login = () => {
    socket = new WebSocket(document.getElementById("IP").value);
    socket.onopen = () => {
        // console.log('连接已建立');
        socket.send(JSON.stringify({
            "type": "login",
            "username": document.getElementById("username").value,
            "password": document.getElementById("password").value
        }));
    };
    socket.onerror = (e) => {
        console.log(e)
    }
    socket.onmessage = (event) => {
        console.log(`收到消息：${event.data}`);
        console.log(typeof(event.data))
        if (typeof(event.data) == "object") {
                var url = URL.createObjectURL(event.data);
                // console.log(Sha256Encrypt(event.data))
                // var img = document.createElement('img');
                // img.src = url;
                // document.body.appendChild(img);
        }
        else {
            data = JSON.parse(event.data);
            // console.log(data.type)
            if (data.type == "ErrorMessage") alert(data.msg);
            else if (data.type == "eval") eval(data.script);
            // console.log(data.binary)
        }
    };
}
// document.getElementById("IP").value = "ws://localhost:8080";
// document.getElementById("username").value = "root";
// document.getElementById("password").value = "root";
login();