
resize = () => {
    w = window.innerWidth;
    h = window.innerHeight;
    if(w < 800)w = 800;
    if(h < 450)h = 450;
    document.getElementById("desktop").style.height = h - 45 + "px";
}
window.onresize = resize;
resize();
url = {};