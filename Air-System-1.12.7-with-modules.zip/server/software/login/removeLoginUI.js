const fs = require("fs");
module.exports = (data,socket) => {
    socket.send(JSON.stringify({
        "type":"eval",
        "script":`document.getElementById("loginUI").style.display = "none";`
    }));
}