module.exports = (msg) => {
    return JSON.stringify({
        "type":"ErrorMessage",
        "msg":msg
    })
}