module.exports = (msg) => {
    return JSON.stringify({
        "type":"Message",
        "msg":msg
    })
}