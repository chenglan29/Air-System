import json
def func(msg):
    return json.dumps({
        "type":"Message",
        "msg":msg
    })