import json
def func(msg):
    return json.dumps({
        "type":"ErrorMessage",
        "msg":msg
    })