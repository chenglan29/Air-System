def isSubset(subset,arr):
    b = 1
    for item in subset:
        flag = 1
        for ele in arr:
            for _item in item.keys():
                if item[_item] != ele[_item]:
                    flag = 0
        if flag == 0:
            return item
    return 0