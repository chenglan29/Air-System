import json
import logging
import time
import os
from modules import isSubset
from modules import socketErrMessage
import asyncio
import websockets
versionNum = 17
versionName = "1.19.17"
# userList = json.loads(json.dumps(open(info["userDataBase"]).read()))
with open('info.json', encoding="utf-8",mode='r') as f:
    info = json.load(f)
with open(info["userDataBase"], encoding="utf-8",mode='r') as f:
    userList = json.load(f)

# 创建一个日志器对象，并设置名称
logger = logging.getLogger('System')
# 设置日志级别，DEBUG用于调试信息、INFO用于普通信息
logger.setLevel(logging.DEBUG)
# 创建控制台处理器，并设置级别
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
# 创建文件处理器，并设置级别
file_handler = logging.FileHandler(info["log"]["outPath"]+ str(int(time.time())) +'.log')
file_handler.setLevel(logging.DEBUG)
# 创建日志格式
formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(name)s - %(message)s')
# 将格式应用于处理器
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)
# 将处理器添加到日志器
logger.addHandler(console_handler)
logger.addHandler(file_handler)

appList = []

def addApp(name):
    if os.path.isfile("./software/"+name+"/index.json"):
        with open("./software/"+name+"/index.json", encoding="utf-8",mode='r') as f:
            item = json.load(f)
            item["path"] = f"software.{name}"
            appList.append(item)
            try:
                if item["supportPython"] != True:
                    logger.error("软件 "+item["name"]+" 的版本无法在本架构(Python)运行")
            except:
                logger.error("软件 "+item["name"]+" 的版本无法在本架构(Python)运行")
            if item["UnavailableSystemVersions"].count(versionNum) != 0:
                logger.error("软件 "+item["name"]+" 的版本无法在本版本("+versionName+")运行")
            elif item["AvailableSystemVersions"].count(versionNum) == 0:
                logger.error("软件 "+item["name"]+" 的版本不支持在本版本("+versionName+")运行，可能会导致运行出错")
for item in os.listdir("./software/"):
    addApp(item)
for item in appList:
    m = isSubset.isSubset(item["dependentSoftwares"],appList)
    if m != 0:
        logger.error(f"{item["name"]}({versionName})-{item["developer"]}所需的依赖{str(m)}未找到")
# 检查依赖
def sortByPriority(arr):
    # 使用[:]创建副本避免修改原数组
    return sorted(arr[:], key=lambda x: x['priority'])
appList = sortByPriority(appList)
dataList = {}
class WebSocketServer:
    def __init__(self, host="0.0.0.0", port=info["port"]):
        self.host = host
        self.port = port
        self.clients = set()  # 存储所有连接的客户端

    async def handle_client(self, socket):
        # 新的客户端连接
        self.clients.add(socket)
        dataList[socket.id] = {
            "doLogin":False
        }
        for item in appList:
            for _item in item["pythonEvent"]["createConnection"]:
                exec(open(_item, encoding='utf-8').read())
        try:
            async for data in socket:
                if len(data) > info["websocket"]["maxSize"]:
                    await socket.send(socketErrMessage.func("过大的数据"))
                else :
                    data = json.loads(data)
                    for item in appList:
                        for _item in item["pythonEvent"]["getMessage"]:
                            exec(open(_item, encoding='utf-8').read())
                    if data["type"] == "login":
                        try:
                            userList[data["username"]]
                            
                        except: 
                            await socket.send(socketErrMessage.func("不存在的用户名"))
                        else:
                            if userList[data["username"]]["password"] != data["password"]: 
                                await socket.send(socketErrMessage.func("密码错误"))
                            else:
                                dataList[socket.id]["level"] = userList[data["username"]]["level"]
                                dataList[socket.id]["dologin"] = True
                                await socket.send(json.dumps({
                                    "type": "Init",
                                    "level": userList[data["username"]]["level"],
                                }))
                                for item in appList:
                                    for _item in item["pythonEvent"]["login"]:
                                        exec(open(_item, encoding='utf-8').read())
                    elif dataList[socket.id]["dologin"] == True:
                        if data["type"] == "ptp":
                            try:
                                appList[data["obj"]]
                            except:
                                await socket.send(socketErrMessage.func("ptp通信失败:不存在该程序"))
                            else:
                                for item in appList[data["obj"]]["pythonEvent"]["ptp"]:
                                    exec(open(item, encoding='utf-8').read())
                        else:
                            for item in appList:
                                for _item in item["pythonEvent"]["getMessage_doLogin"]:
                                    exec(open(_item, encoding='utf-8').read())
                logger.debug(f"收到消息: {data}")
                # 回显消息给客户端
                # await socket.send(f"服务器已收到: {message}")
        except websockets.ConnectionClosed as e:
            logger.debug(f"客户端断开连接: {e}")
        finally:
            # 移除断开的客户端
            self.clients.remove(socket)
            for item in appList:
                for _item in item["pythonEvent"]["closeConnection"]:
                    exec(open(_item, encoding='utf-8').read())
    async def send(self, message):
        """向所有连接的客户端发送消息"""
        if not self.clients:
            logger.debug("没有客户端连接，无法发送消息")
            return
        disconnected_clients = set()
        for client in self.clients:
            try:
                await client.send(message)
            except websockets.ConnectionClosed:
                disconnected_clients.add(client)
                for item in appList:
                    for _item in item["pythonEvent"]["closeConnection"]:
                        exec(open(_item, encoding='utf-8').read())
        # 清理已断开的客户端
        self.clients -= disconnected_clients
        
    async def start(self):
        logger.info(f"启动 WebSocket 服务器: ws://{self.host}:{self.port}")
        async with websockets.serve(self.handle_client, self.host, self.port):
            await asyncio.Future()  # 持续运行直到手动停止
async def main():
    # 创建 WebSocket 服务器实例
    websocket_server = WebSocketServer()
    websocket_task = asyncio.create_task(websocket_server.start())  # 启动 WebSocket 服务器
    for item in appList:
        for _item in item["pythonEvent"]["initServer"]:
            exec(open(_item, encoding='utf-8').read())
    await asyncio.gather(websocket_task)


if __name__ == "__main__":
    asyncio.run(main())