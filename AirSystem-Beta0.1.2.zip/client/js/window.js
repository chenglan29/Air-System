let zIndex = 1;

class Window {
    constructor(value) {
        this.isMaximized = false;
        this.originalState = {};
        this.createWindow(value);
        //传递
    }
    createWindow(value = {}) {
        //预参数
        if(!value.width)value.width = w/10*8;
        if(!value.height)value.height = h/10*8;
        if(!value.top)value.top = Math.floor(Math.random()*(h/10*2-45));
        if(!value.left)value.left = Math.floor(Math.random()*w/10*2);
        if(!value.title)value.title = "无标题";
        if(!value.content)value.content = "";
        if(!value.src)value.src = "";
        // 创建窗口元素
        this.window = document.createElement('div');
        //设置样式
        this.window.className = 'window';
        this.window.style.width = value.width + "px";
        this.window.style.height = value.height + "px";
        this.window.style.top = value.top + "px";
        this.window.style.left = value.left + "px";
        // 标题栏
        const titleBar = document.createElement('div');
        titleBar.className = 'title-bar';
        // 窗口按钮
        const buttons = document.createElement('div');
        buttons.className = 'window-buttons';
        this.maxButton = document.createElement('button');
        this.maxButton.className = 'window-button';
        this.maxButton.textContent = '🗖';
        this.closeButton = document.createElement('button');
        this.closeButton.className = 'window-button';
        this.closeButton.textContent = '×';
        buttons.appendChild(this.maxButton);
        buttons.appendChild(this.closeButton);
        // 标题
        const title = document.createElement('span');
        title.innerHTML = value.title;
        titleBar.appendChild(title);
        titleBar.appendChild(buttons);
        // 内容区域
        var content;
        if(value.src != ""){
            content = document.createElement('iframe');
            // content.sandbox = "allow-scripts allow-same-origin allow-popups";
            content.src = value.src;
            content.className = "content";
            // content.style.height = h / 10 * 8 + "px";
            content.style.padding = "0";
        }
        else {
            content = document.createElement('div');
            content.className = 'content';
            content.innerHTML = value.content;
        }
        // 调整大小手柄
        const resizeHandle = document.createElement('div');
        resizeHandle.className = 'resize-handle';
        // 组合元素
        this.window.appendChild(titleBar);
        this.window.appendChild(content);
        this.window.appendChild(resizeHandle);
        document.body.appendChild(this.window);
        // 事件绑定
        this.setupEvents();
    }
    setupEvents() {
        // let isDragging = false;
        // let startX, startY, startLeft, startTop;
        // let isOperating = false;
        this.window.addEventListener("mousedown",()=>{
            this.window.style.zIndex = ++zIndex;
        })
        // 标题栏拖动
        this.window.querySelector('.title-bar').addEventListener('mousedown', e => {
            // isDragging = true;
            opera.type = "moveWindow";
            opera.obj = this.window;
            [opera.temp.startX, opera.temp.startY] = [e.clientX, e.clientY];
            [opera.temp.startLeft, opera.temp.startTop] = [parseInt(this.window.style.left), parseInt(this.window.style.top)];
        });
        this.window.querySelector('.title-bar').addEventListener("mousemove",()=>{
            if(this.isMaximized == true && opera.type == "moveWindow")this.enlarge();
        })
        
        // 最大化按钮
        this.enlarge = () => {
            if (!this.isMaximized) {
                //放大
                //记录初始状态，缩小时直接调用
                this.originalState = {
                    left: this.window.style.left,
                    top: this.window.style.top,
                    width: this.window.style.width,
                    height: this.window.style.height
                };

                this.window.style.left = '0';
                this.window.style.top = '0';
                this.window.style.width = '100%';
                this.window.style.height = h - 45 +"px";
                this.maxButton.textContent = '🗗';
                this.window.querySelector('.resize-handle').style.cursor = "not-allowed";
            } else {
                //缩小
                Object.entries(this.originalState).forEach(([key, value]) => {
                    this.window.style[key] = value;
                });
                this.maxButton.textContent = '🗖';
                this.window.querySelector('.resize-handle').style.cursor = "nwse-resize";
            }
            this.isMaximized = !this.isMaximized;
        }
        this.maxButton.addEventListener('click', this.enlarge);
        // document.addEventListener('mousemove', e => {
        //     if (!isDragging) return;
        //     if(e.clientX > 0 && e.clientX < w){
        //         const dx = e.clientX - startX;
        //         this.window.style.left = `${startLeft + dx}px`;
        //     }
        //     if(e.clientY > 0 && e.clientY < h - 45){
        //         const dy = e.clientY - startY;
        //         this.window.style.top = `${startTop + dy}px`;
        //     }
        // });
        // document.addEventListener('mouseup', () => {
        //     isDragging = false;
        // });
        // 关闭按钮
        this.closeButton.addEventListener('click', () => {
            this.window.remove();
        });

        // 调整大小
        // let isResizing = false;
        const resizeHandle = this.window.querySelector('.resize-handle');

        // this.window.addEventListener('click', () => {
        //     this.window.zIndex = ++zIndex;
        // });
        //这段注释的代码重复了，故省略
        resizeHandle.addEventListener('mousedown', e => {
            if(this.isMaximized == true)return;
            opera.type = "reSizeWindow";
            // isResizing = true;
            e.preventDefault();
            opera.temp.startX = e.clientX;
            opera.temp.startWidth = this.window.offsetWidth;
            opera.temp.startY = e.clientY;
            opera.temp.startHeight = this.window.offsetHeight;
            opera.obj = this.window;
            // const startX = e.clientX;
            // const startWidth = this.window.offsetWidth;
            // const startY = e.clientY;
            // const startHeight = this.window.offsetHeight;
            // function resize(e, t) {
            //     if (isResizing) {
            //         if(e.clientX < w && e.clientX > 0){
            //             const newWidth = startWidth + (e.clientX - startX);
            //             t.window.style.width = `${newWidth}px`;
            //         }
            //         if(e.clientY < h - 45 - 10 && e.clientY > 0){
            //             const newHeight = startHeight + (e.clientY - startY);
            //             t.window.style.height = `${newHeight}px`;
            //         }
            //     }
            // }
            // document.addEventListener('mousemove', () => { resize(event, this) });
            // document.addEventListener('mouseup', () => {
            //     isResizing = false;
            //     document.removeEventListener('mousemove', () => { resize(event, this) });
            // });
            // 旧代码：移速过快容易出问题
        });

    }
}

