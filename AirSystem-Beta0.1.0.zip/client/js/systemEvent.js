opera = {
    "type":"",
    "obj":undefined,
    "temp":{}
}
window.addEventListener("mousemove",(e)=>{
    // console.log(e);
    if(opera.type == "reSizeWindow"){//调整窗口大小
        if(e.clientX < w && e.clientX > 0){
            const newWidth = opera.temp.startWidth + (e.clientX - opera.temp.startX);
            opera.obj.style.width = `${newWidth}px`;
        }
        if(e.clientY < h - 45 - 10 && e.clientY > 0){
            const newHeight = opera.temp.startHeight + (e.clientY - opera.temp.startY);
            opera.obj.style.height = `${newHeight}px`;
        }
        console.log(e)
    }
    else if(opera.type == "moveWindow"){//移动窗口
        if(e.clientX > 0 && e.clientX < w){
            const dx = e.clientX - opera.temp.startX;
            opera.obj.style.left = `${opera.temp.startLeft + dx}px`;
        }
        if(e.clientY > 0 && e.clientY < h - 45){
            const dy = e.clientY - opera.temp.startY;
            opera.obj.style.top = `${opera.temp.startTop + dy}px`;
        }
    }
});
window.addEventListener("mouseup",(e)=>{
    opera.type = "";
});
window.addEventListener("mousedown",(e)=>{
    
});
window.addEventListener("mouseleave",(e)=>{
    opera.type = "";
});