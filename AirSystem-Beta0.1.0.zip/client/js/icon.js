//此文件用于显示桌面图标
//图标列表
//使用二位数组，横向长度依据[0].length，留空可用 0
iconList = [
    [
        {icon:"",name:"百度",dblclick:()=>{new Window({"title":"百度","src":"http://m.baidu.com"});}},
        {icon:"",name:"bilibili",dblclick:()=>{new Window({"title":"bilibili","src":"http://bilibili.com"});}},
    ],
    [
        {icon:"",name:"空",dblclick:()=>{new Window();}},
        0
    ]
];

for(var i = 0;i<iconList.length;i++){
    for(var j = 0;j<iconList[0].length;j++){
        if(iconList[i][j] == 0)continue;
        var icon = document.createElement("div");
        var iconImg = document.createElement("img");
        var iconName = document.createElement("div");
        icon.className = "icon";
        icon.style.top = i * 80 + "px";
        icon.style.left = j * 80 + "px";
        if(iconList[i][j].dblclick)icon.addEventListener("dblclick",iconList[i][j].dblclick);
        icon.addEventListener("click",()=>{
            icon.style.background = "rgba(0,127,255,0.2)"
        });
        iconImg.className = "iconImg";
        iconImg.src = iconList[i][j].icon;

        iconName.className = "iconName";
        iconName.innerHTML = iconList[i][j].name;

        icon.appendChild(iconImg);
        icon.appendChild(iconName);
        document.getElementById("desktop").appendChild(icon);
    }
}
